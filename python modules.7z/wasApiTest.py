import urllib
import urllib2
import json
import time


while response == '':
    try:
       url = 'http://pt00.devfg.rbc.com/mdwAPI.php'
       data = json.dumps(['HostName','WAS Version'])
       headers = {'content-type': 'application/json'}
       opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
       opener.addheaders.append(('Cookie', 'PHPSESSID=md05r6c6t71pko4pbrbkcgdcra'))
       response = opener.open('http://pt00.devfg.rbc.com/mdwAPI.php')
       data = json.load(response)
       print data[0]
	except:
	   print("Connection refused by the server..")
       print("Let me sleep for 5 seconds")
       print("ZZzzzz...")
       time.sleep(10)
       print("Was a nice sleep, now let me continue...")
       continue