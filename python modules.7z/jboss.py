import pandas as pd
import utilites as util
import numpy as np
import logic as l

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server
def merge_iipm(data,iipm):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    print len(data)
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    print len(data)
    data[data['APP_CODE'].isnull()].to_csv('./jboss_servers_missing.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Obtain the old data
def curr_platform(platform='JBoss'):
    data = util.read_mongo('kri', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['DATE','SERVER_NAME','COMMENTS','SERVICE_WINDOW_CYCLE','APP_CODE','STRATEGY']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    #check data > file
    #data.to_csv("output.csv", sep=',', encoding='utf-8')
    return data

def prep_data():
    data = pd.read_csv('JBOSS MDW.csv')
    print len(data)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['DB_COUNT'] = ""
    data['SERVICE_WINDOW_CYCLE'] = ""
    data['STRATEGY'] = ""
    data['COMMENTS'] = ""
    data['DATE'] = ""
    data['SOURCE'] = "N/A"
    data['TYPE'] = "N/A"
    data['PLATFORM_NAME'] = "JBoss"
    data['INSTANCE_NM'] = "N/A"
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].astype(str)
    data['APP_CODE'] = data['APP_CODE'].str.strip()
    return data


def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    master = util.read_mongo('kri','master_view')
    db = util._connect_mongo()
    db['master_business_works_temp'].drop()
    util.insert_mongo(master, 'master_jboss_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'JBoss'})
    util.insert_mongo(data, 'master_view')


def jbossfinal():
    #get data from iipm table
    iipm = util.read_mongo('kri', 'iipm')
    db = util._connect_mongo()
    #get data from csv file
    data = prep_data()
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data,iipm)
    print len(data)
    #get data from master_view with columnes ['DATE','SERVER_NAME','COMMENTS','STRATEGY']
    #oldJBoss = curr_platform()
    #print oldJBoss
    #data = data.merge(oldJBoss,on=['APP_CODE','SERVER_NAME'],how='left')
    data.drop_duplicates(['SERVER_NAME','APP_CODE'],inplace=True)
    print "size of file after dropping duplicates"
    print len(data)

    #update master_business_works_temp with old master_view;
    #update master_view(BusinessWorks) with merged data
    #shipp(data)
    #data.to_csv("jbossdata.csv")

    return data;

data =  jbossfinal()