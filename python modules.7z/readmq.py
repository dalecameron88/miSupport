# encoding: utf-8

import pandas as pd
import pyodbc
import pandas.io.sql as psql
import numpy as np
from datetime import date
import datetime
import sys
reload(sys)
sys.setdefaultencoding('utf8')
data = pd.read_csv('MQ MDW.csv',encoding='cp1252')
data = data.applymap(str)

data['install date'] = pd.to_datetime(data['install date'], format='%Y-%m-%d', errors='coerce')
install = datetime.date(int('2017'),int('12'),int('21'))
data = data.replace('nan','',regex=True)

cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
                        'Port=1433'
                        'uid=DLBV0SRVMW'
                        'pwd=H1b^sTr0n%'
                         )




for c in data:
    if data[c].dtype == 'object':
        print('Max length of column %s: %s\n' %  (c, data[c].map(len).max()))

cursor = cnxn.cursor()


print data

def mq():
 for index,row in data.iterrows():
         cursor.execute("INSERT INTO mw_instance (server_name,software_component,app_app_code,software_component_version,version,platform,environment,attestation,install_type,ha_version,standby_mode,location,status,ha_fqdn,qmgr_name,QMGR_Port,comments,end_of_support, install) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
         str(row['server_name']),str(row['software_component']),str(row['app_app_code']),str(row['software_component_version']),str(row['version']),str(row['platform']),str(row['environment']),str(row['attestation']),str(row['install_type']),str(row['ha_version']),str(row['standby_mode']),str(row['location']),str(row['status']),str(row['FQDN']),str(row['QMGR_name']),str(row['QMGR_Port']),row['comments'].encode('utf-8'), str(row['end_of_support']), str(row[install]).replace("-", "/"))
         cnxn.commit()
         cnxn.close

mq()


#strg = '{:%B %d, %Y}'.format(dt)

#dt = datetime.now()

# str.format
#strg = '{:%B %d, %Y}'.format(dt)
#print(strg)  # July 22, 2017

# datetime.strftime
#strg = dt.strftime('%B %d, %Y')
#print(strg)  # July 22, 2017

# f-strings in python >= 3.6
#strg = f'{dt:%B %d, %Y}'
#print(strg)  # July 22, 2017