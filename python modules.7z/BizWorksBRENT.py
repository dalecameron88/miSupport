import pandas as pd
import utilities as util
import pyodbc
import numpy as np
import logic as l

#mdw DB connection string
#conn = pyodbc.connect(conn_str)
#conn.set_attr(pyodbc.SQL_ATTR_TXN_ISOLATION, pyodbc.SQL_TXN_SERIALIZABLE)

cnxn = pyodbc.connect( 'Driver={ODBC Driver 13 for SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105,1433;'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server # df.set_index('book').authors.str.split(',', expand=True).stack().reset_index('book')
def merge_iipm(data,iipm):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    data['APP_CODE'] = data['APP_CODE'].str.strip()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data[data['APP_CODE'].isnull()].to_csv('BusinessWorks_servers_missing.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Obtain the old data
def curr_platform(platform='BusinessWorks'):
    data = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['APP_CODE','DATE','SERVER_NAME','COMMENTS','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    #check data > file
    #data.to_csv("output.csv", sep=',', encoding='utf-8')
    return data

def read_mw_app_code():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT  mv_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,version as CURRENT_VERSION from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active'")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('BissnessWorksDATAFRMMDW123.csv',encoding='utf-8')
    return data;

def parse_app_code(row):
        return str(row['APP_CODE']).split('/')[0];

def read_grouped_app_code():
    sql1 = ("SELECT grouped_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT, version as CURRENT_VERSION from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active' AND grouped_app_code NOT LIKE '%/%' AND grouped_app_code != '' ")
    data = pd.read_sql_query(sql1,cnxn)
    data = data[data['APP_CODE'].notnull()]
    data2 = pd.concat([pd.Series(row['SERVER_NAME'], row['APP_CODE'].split(',')) for _, row in data.iterrows()]).reset_index()
    data2.columns = ['APP_CODE', 'SERVER_NAME']
    data2 = data2[data2['APP_CODE'].notnull()]
    del data['APP_CODE']
    df = data2.merge(data,on=['SERVER_NAME'])
    df = df[df['APP_CODE'].notnull()]
    print df
    return df

def read_changing_app_code():
    sql1 = ("SELECT grouped_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT, version as CURRENT_VERSION from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active' AND grouped_app_code LIKE '%/%' ")
    sqldata = pd.read_sql_query(sql1,cnxn)
    data = sqldata.replace('\n','', regex=True) #Used to clean up the string
    data['APP_CODE'] = data.apply(parse_app_code,axis=1)
    print data[['APP_CODE']]
    data = pd.concat([pd.Series(row['SERVER_NAME'], row['APP_CODE'].split(',')) for _, row in data.iterrows()]).reset_index()
    data.columns = ['APP_CODE', 'SERVER_NAME']
    del sqldata['APP_CODE']
    df = data.merge(sqldata,on=['SERVER_NAME'])
    print df
    return df

def prep_data():
    df1 = read_mw_app_code()
    df2 = read_grouped_app_code()
    df3 = read_changing_app_code()

    data = pd.concat([df1,df2,df3],ignore_index=True)
    data['CURRENCY'] = data.apply(l.currency('businessworks'),axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    data['END_SUPPORT'] = data.apply(l.EOL('businessworks'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['DB_COUNT'] = ""
    data['SOURCE'] = "N/A"
    data['TYPE'] = "N/A"
    data['PLATFORM_NAME'] = "BusinessWorks"
    data['INSTANCE_NM'] = "N/A"
    data['TSS_PERCENTAGE'] = None
    data['TSS_PASS_FAIL'] = None
    data['TSS_LINK_REPORT'] = None
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].astype(str)
    print data
    return data


#Get the OS's BusinessWorks is installed on
def get_servers(servers=["WINDOWS",'REDHAT', 'AIX' , 'iSeries' ]):
    data = util.read_mongo('dev', 'master_view', query={ "PLATFORM_NAME": { "$in": servers } })
    data = data[['SERVER_NAME']]
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    return data;


def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_business_works_temp'].drop()
    util.insert_mongo(master, 'master_business_works_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'BusinessWorks'})
    util.insert_mongo(data, 'master_view')


def businessworksfinal():
    #get data from iipm table
    iipm = util.read_mongo('dev', 'iipm')
    db = util._connect_mongo()
    #get data from csv file
    data = prep_data()
    
    servers = get_servers(servers=["WINDOWS",'REDHAT', 'AIX', 'iSeries', 'SOLARIS' ]); #Obtain the OS's MQ is installed on
    data = pd.merge(data, servers, on='SERVER_NAME',how='left',indicator=True) #Merge the data to check for matches
    data.to_csv('data.csv')
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data,iipm)
    print len(data)
    oldBusinessWorks = curr_platform()
    data = data.merge(oldBusinessWorks,on=['SERVER_NAME','APP_CODE'],how='left')
    data = data.drop_duplicates(["APP_CODE", "SERVER_NAME"])
    print "size of file after dropping duplicates"
    print len(data)

    #update master_business_works_temp with old master_view;
    #update master_view(BusinessWorks) with merged data
    #shipp(data)
    return data;

if __name__ == '__main__':
    data = businessworksfinal()
    data.to_csv("BusinessWorksData.csv")
    #data.to_csv('TESTBizWorksAug01.csv',encoding='utf-8',index=None)