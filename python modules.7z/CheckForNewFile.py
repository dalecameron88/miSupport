import os, sys

import win32file
import win32con
import middlewareUtil as util
import pandas as pd
import pandas.io.sql as psql
import pandas as pd
import numpy as np

path_to_watch = "." # look at the current directory
file_to_watch = "sybase.csv" # look for changes to a file called test.txt
data = pd.read_csv('sybase.csv')

#print data, row[index]
#import os,sys
folder = 'C:/Users/330071796/Desktop'
for filename in os.listdir(folder):
    if filename.endswith(".iqy"):
#	   filename = os.path.splitext(filename)[0]
       infilename = os.path.join(filename)
	   
#old_file = os.path.join("C:/Users/330071796/Desktop", "solaris.iqy")
#new_file = os.path.join("C:/Users/330071796/Desktop", "solaris.xls")

# newname=os.rename(infilename, new_file)
#      newname = 'solaris.xlsx' %infilename
       newname = filename.replace('.iqy', '.xls')
#   '%d days and %d nights' % (40, 40)
print(newname)
#filename = os.path.splitext(filename)[0]
data = pd.read_csv('solaris.xls')


def ProcessNewData( newText ):
    print "Text added: %s"%newText
#print data, row[index]

# Set up the bits we'll need for output
ACTIONS = {
  1 : "Created",
  2 : "Deleted",
  3 : "Updated",
  4 : "Renamed from something",
  5 : "Renamed to something"
}
FILE_LIST_DIRECTORY = 0x0001
hDir = win32file.CreateFile (
  path_to_watch,
  FILE_LIST_DIRECTORY,
  win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE,
  None,
  win32con.OPEN_EXISTING,
  win32con.FILE_FLAG_BACKUP_SEMANTICS,
  None
)

# Open the file we're interested in
#a = open(data, "r")
a = pd.read_csv('weblogic.csv')
db = util._connect_mongo()
connection = db['master_view']

data = data.replace(np.nan, '', regex=True)

#JOBS TO BE ADDED FOR WEBLOGIC CSV
def update_info():
    for index,row in data.iterrows():
        if row['SERVER_NAME'] is not None:
              connection.update({
              'APP_CODE':row['APP_CODE'],
              'SERVER_NAME': row['SERVER_NAME'],
              'PLATFORM_NAME':'Sybase',
              },{
              '$set': {
              'DATE':row['DATE'],
              'STRATEGY': row['STRATEGY'],
              }
              }, multi=True,upsert=False)
print data
# Throw away any exising log data
#a.read()

# Wait for new data and call ProcessNewData for each new chunk that's written
while 1:
  # Wait for a change to occur
  results = win32file.ReadDirectoryChangesW (
    hDir,
    1024,
    False,
    win32con.FILE_NOTIFY_CHANGE_LAST_WRITE | \
        win32con.FILE_NOTIFY_CHANGE_DIR_NAME   | \
        win32con.FILE_NOTIFY_CHANGE_ATTRIBUTES | \
        win32con.FILE_NOTIFY_CHANGE_SIZE       | \
        win32con.FILE_NOTIFY_CHANGE_LAST_WRITE | \
        win32con.FILE_NOTIFY_CHANGE_SECURITY,
    None,
    None
  )

  # For each change, check to see if it's updating the file we're interested in
  for action, file in results:
    full_filename = os.path.join (path_to_watch, file)
    #print file, ACTIONS.get (action, "Unknown")
    if file == file_to_watch:
        newText = pd.read_csv('sybase.csv')
        ProcessNewData( newText )

			