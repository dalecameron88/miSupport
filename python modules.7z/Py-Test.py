------------------Working-----------------------------------

def update_usrinput(data,collection,key='_id'):
    """ A util for updating mongo --kri db default--  """
    #bulk objs to be updated
    objs = []
    client = _connect_mongo()
    #table to be connected
    coll = client[collection];

    print ('this is the data')
    print data
    counter = 0
    status = []
    for index, row in data.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));

        counter+=1

        if 'DATE' in obj:

             print obj['DATE']
             if obj['DATE'] == None:
              print 'No date entered'
             else:
                 print 'entered else'
                 datestatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'DATE': obj['DATE']}},return_document= ReturnDocument.AFTER)
                 print datestatus['DATE']
                 print obj['DATE']
                 if datestatus['DATE'] == obj['DATE']:
                     print 'Date was updated'
                     status.append(obj[key] + ' updated')
                 else:
                     status.append(obj[key] + ' not updated')

                 print counter
        else:
          print 'No date in object'

        if 'COMMENTS' in obj:
            if obj['COMMENTS'] == None:
              print 'No comments entered'
            else:
               commentstatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'COMMENTS': str(obj['COMMENTS']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
               if commentstatus['COMMENTS'].encode('utf-8') == obj['COMMENTS'].encode('utf-8'):
                   print 'Comments was updated'
                   print commentstatus['COMMENTS']
                   print obj['COMMENTS']
                   status.append(obj[key] + ' updated')
               else:
                   status.append(obj[key] + ' not updated')
        else:
            print 'No comments in object'
		
	if 'SERVICE_WINDOW_CYCLE' in obj:
            if obj['SERVICE_WINDOW_CYCLE'] == None:
              print 'No comments entered'
            else:
               commentstatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'SERVICE_WINDOW_CYCLE': str(obj['SERVICE_WINDOW_CYCLE']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
               if commentstatus['SERVICE_WINDOW_CYCLE'].encode('utf-8') == obj['SERVICE_WINDOW_CYCLE'].encode('utf-8'):
                   print 'Comments was updated'
                   print commentstatus['SERVICE_WINDOW_CYCLE']
                   print obj['SERVICE_WINDOW_CYCLE']
                   status.append(obj[key] + ' updated')
               else:
                   status.append(obj[key] + ' not updated')
        else:
            print 'No comments in object'

        if 'STRATEGY' in obj:
              if obj['STRATEGY'] == None:
                  print 'No strategy entered'
              else:
               strategystatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'STRATEGY': str(obj['STRATEGY']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
               if strategystatus['STRATEGY'].encode('utf-8') == obj['STRATEGY'].encode('utf-8'):
                     print strategystatus['STRATEGY']
                     print obj['STRATEGY']
                     status.append(obj[key] + ' updated')
               else:
                     status.append(obj[key] + ' not updated')

        else:
               print 'No strategy in object'

    print status
    if 'not updated' in status:
        check = '404'
    else:
        check = '201'
    print check
    return check
	
	
	
------------------IN WORK-----------------------------------


def update_usrinput(data,collection,key='_id'):
	""" A util for updating mongo --kri db default--  """
	#bulk objs to be updated
	objs = []
	client = _connect_mongo()
	#table to be connected
	coll = client[collection];

	print 'this is the data'
	print data
	counter = 0
	status = []
	for index, row in data.iterrows():
		obj = row.to_json();
		obj = json.loads(obj.decode("utf-8","ignore"));

		counter+=1

		if 'SERVICE_WINDOW_CYCLE' in obj:

			 print obj['SERVICE_WINDOW_CYCLE']
		if 'SERVER_NAME' in obj:
		
			 print obj['SERVER_NAME']
		if 'APP_CODE' in obj:

			 print obj['APP_CODE']
 
		if 'PLATFORM_NAME' in obj:

			 print obj[PLATFORM_NAME]		
			
			 if obj['SERVICE_WINDOW_CYCLE'] == None:
			  print 'No date entered'
			 else:
				 print 'entered else'
				 datestatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'SERVICE_WINDOW_CYCLE': obj['SERVICE_WINDOW_CYCLE']}},return_document= ReturnDocument.AFTER)
				 cursor.execute("INSERT INTO mw_instance (service_window_cycle) VALUES (SERVICE_WINDOW_CYCLE) WHERE SERVER_NAME = SERVER_NAME AND PLATFORM_NAME = PLATFORM_NAME AND APP_CODE = APP_CODE",(service_window_cycle))
				 try:
					cnxn.commit()	 
					resp = '201'
				 except pyodbc.Error as ex:
					 sqlstate = ex.args[0] + ex.args[1]
					 print(sqlstate)
					 resp = '404'
				 cnxn.close
				 return resp
				 print datestatus['SERVICE_WINDOW_CYCLE']
				 print obj['SERVICE_WINDOW_CYCLE']
				 if datestatus['SERVICE_WINDOW_CYCLE'] == obj['SERVICE_WINDOW_CYCLE']:
					 print 'Date was updated'
					 status.append(obj[key] + ' updated')
				 else:
					 status.append(obj[key] + ' not updated')

				 print counter
		else:
		  print 'No date in object'

		if 'COMMENTS' in obj:
			if obj['COMMENTS'] == None:
			  print 'No comments entered'
			else:
			   commentstatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'COMMENTS': str(obj['COMMENTS']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
			   if commentstatus['COMMENTS'].encode('utf-8') == obj['COMMENTS'].encode('utf-8'):
				   print 'Comments was updated'
				   print commentstatus['COMMENTS']
				   print obj['COMMENTS']
				   status.append(obj[key] + ' updated')
			   else:
				   status.append(obj[key] + ' not updated')
		else:
			print 'No comments in object'

		if 'STRATEGY' in obj:
			  if obj['STRATEGY'] == None:
				  print 'No strategy entered'
			  else:
			   strategystatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'STRATEGY': str(obj['STRATEGY']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
			   if strategystatus['STRATEGY'].encode('utf-8') == obj['STRATEGY'].encode('utf-8'):
					 print strategystatus['STRATEGY']
					 print obj['STRATEGY']
					 status.append(obj[key] + ' updated')
			   else:
					 status.append(obj[key] + ' not updated')

		else:
			   print 'No strategy in object'

	print status
	if 'not updated' in status:
		check = '404'
	else:
		check = '201'
	print check
	return check
