
# coding: utf-8

# In[30]:

import utilites as util
import pandas as pd
from pymongo import MongoClient
import pyodbc
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json


#Renamed columns, these columns are used to rename columns that are different in the excel spreadsheet and it is done so that it can match the mongoDB fields
renamed_columns={
                    'AppCode': 'APP_CODE',
                    'Strategy':'STRATEGY' ,
                    'Server': 'SERVER_NAME',
                    'Date': 'MIGRATION_DATE',
                    'Status':'STATUS',
                    'Comments':'COMMENT',
                    'Environment':'ENVIRONMENT',
                    'App Name':'APP_NAME',
                    'L3 Org':'L3_ORG',
                    'App Custodian':'APP_CUSTODIAN',
                    'Curr Ver':'CURRENT_VERSION',
                    'END_SUPPORT':'END_SUPPORT',
                    'Target Ver':'TARGET_VERSION',
                    'Cr #': 'CR_NUMBER',
                    'PlatForm': 'PLATFORM_TYPE'
                        }

cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )

#Read the csv file and prepare the data
def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_SUPPORT from mw_instance WHERE software_component='DB2' AND STATUS = 'Active' AND product_name IN ('DB2', ' ')")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('DB2DATAFRMMDW123.csv',encoding='utf-8')
    return data;

#This method is used to obtain the DB2 version that is installed using .split
def parse_version(df):
    if str(df['CURRENT_VERSION']) == 'none':
            return 'none';
    else:
            return str(df['CURRENT_VERSION']);

def prep_initial():
    data = read_file(); #Read the file and then for each record in the file creates a dataframe column
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'] #Used create the current the current version
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].str[0:4]
    data['CURRENCY'] = data.apply(l.currency('db2'),axis=1) #Used to create the currency column - determine the currency based on the current versiion
    data['END_SUPPORT'] = data.apply(l.EOL('db2'),axis=1) #Used to create the END_OF_SUPPORT column - determine the currency based on the current version
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1) # Used to determine compliance based on the End of Support date
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['HSP_LINK'] = data.apply(l.hsp_link,axis=1)
    data = data.replace(np.nan, '', regex=True)
    return data;

def prep_data():
    data = prep_initial()
    data = l.rename(data, renamed_columns); #rename the CSV colummns to what our database has
    data['PLATFORM_NAME'] = 'DB2'
    del data['APP_CODE']
    del data['ENVIRONMENT']
    data['SERVER_NAME'] = data['SERVER_NAME'].str.replace(' ', '')
    data['SERVER_NAME']  =  data['SERVER_NAME'].str.lower()
    data['SERVER_NAME'] = data['SERVER_NAME'].str.split('.').str[0]
    data['TYPE'] = 'N/A'
    data['SOURCE'] = 'N/A'
    data['DB_COUNT'] = 'N/A'
    data['INSTANCE_NM'] = 'N/A'
    return data;

#Get the OS's DB2 is installed on
def get_servers(servers=["WINDOWS",'REDHAT', 'AIX','Linux', 'NT', 'Unix', 'zLinux']):
    data = util.read_mongo('devuser', 'master_view', query={ "PLATFORM_NAME": { "$in": servers } })
    data = data[['APP_CODE', 'SERVER_NAME', 'ENVIRONMENT']] #Reserve the APP_CODE, SERVER_NAME, and Environment for merging purposes
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    return data;

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server
def merge_iipm(data, iipm):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Check for missing dates
def check_dates(data,oldDB2):
    print "dates on new portal"
    print len(data[data['DATE'].notnull()])
    dateMiss = oldDB2[oldDB2['DATE'].notnull()].merge(data[data['DATE'].notnull()],indicator=True,on="SERVER_NAME",how='left')[['SERVER_NAME','APP_CODE','_merge']]
    dateMiss = dateMiss[dateMiss['_merge'] == 'left_only']
    dateMiss.to_csv('db2_date_missing.csv', index=False, columns=['APP_CODE','SERVER_NAME'])
    print "dates on pervious dataset:"
    print len(oldDB2[oldDB2['DATE'].notnull()])


#Obtain the old data
def curr_platform(platform='DB2'):
    data = util.read_mongo('devuser', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['DATE','SERVER_NAME','COMMENTS','STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    return data;

#Method used to create a backup then insert the new data into mongo db
def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    data.drop_duplicates('SERVER_NAME', inplace=True)
    master = util.read_mongo('devuser','master_view')
    db = util._connect_mongo()
    db['master_db2_temp'].drop()
    util.insert_mongo(master, 'master_db2_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'DB2'})
    util.insert_mongo(data, 'master_view')

def db2_final():
    iipm = util.read_mongo('devuser','iipm') #Read IIPM for the correct data
    data = prep_data(); #Prepare the data for processing
    servers = get_servers(servers=["WINDOWS",'REDHAT', 'AIX','Linux', 'NT', 'Unix', 'zLinux']); #Obtain the OS's DB2 is installed on
    data = pd.merge(data, servers, on='SERVER_NAME', how='left') #Merge the data to check for matches
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data, iipm);
    print len(data)
    oldDB2 = curr_platform()
    data = data.merge(oldDB2, on='SERVER_NAME', how='left') ##Merge the new data with the old data in order to preserve the comments, date, strategy, and comments
    data.drop_duplicates('SERVER_NAME', inplace=True)
    check_dates(data, oldDB2); #Check to see if any dates were dropped
    data.loc[data['CURRENT_VERSION'] == 'none', 'COMPLIANCE'] = 'Approaching Non Compliant (EOL within 18mths)' #Used to fix missing versions
    #shipp(data); #Send the data to be inserted into mongo db
    return data;
if __name__ == '__main__':
    data = db2_final()
data.to_csv('TESTDB2-123.csv',encoding='utf-8',index=None)