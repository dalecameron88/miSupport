# coding: utf-8

# In[ ]:

import flask
from flask import Flask, request
from flask_restful import Resource, Api
from sqlalchemy import create_engine
from json import dumps
from flask import jsonify
import middlewareUtil as util
import json
from pymongo import MongoClient
from bson.json_util import dumps
import pandas as pd
import numpy as np
import DataTableServer as dt
from waitress import serve
import numpy as np
import pandas as pd
from io import BytesIO
from flask import Flask, send_file, make_response
from pandas.io.json import json_normalize


# In[ ]:

app = Flask(__name__)
api = Api(app)

#need to pass l(l3, l4, ...)
class ls(Resource):
	def get(self):
		output = util.read_mongo('dev', 'ls')
		output.columns = [x.lower() for x in output.columns]
		output = output.replace(np.nan, '', regex=True)
		output = output.to_dict(orient='records')
		return jsonify({
			'summary':{
					'total': len(output),
					'source': 'IIPM',
						},
					'results':output
					})

@app.route('/api/inv_master_table')
def server():
	columns = [ 'APP_CODE', 'SERVER_NAME', 'PLATFORM_NAME' ,'MIGRATION_ELIGIBILITY','END_SUPPORT', 'CURRENT_VERSION', 'ENVIRONMENT', 'APP_NAME', 'L3_ORG', 'L3', 'L4', 'L5', 'TYPE', 'SOURCE', 'DB_COUNT', 'DATE', 'APP_CUSTODIAN','COMMENTS', 'STRATEGY', 'INSTANCE_NM', '_id','SERVICE_WINDOW_DATE']
	index_column = "_id"
	collection = "master_view"
	results = dt.DataTablesServer(request, columns, index_column, collection).output_result()

	# return the results as a string for the datatable
	return json.dumps(results)

@app.route('/api/update_date', methods=['POST'])
def get_date():
	try:
		content = request.get_json()
		df = json_normalize(content);
		resp = flask.make_response('{"status": "ok"}')
		resp.headers['Content-Type'] = "application/json"
		#print df
		util.update_mongo(df,'master_view', key='_id')
	except:
		resp = flask.make_response('{"status": "error"}')
		resp.headers['Content-Type'] = "application/json"
		#print resp
	return resp;

@app.route('/api/update_usrinput', methods=['POST'])
def update_usrinput():
	try:
		content = request.get_json()
		df = json_normalize(content);
		print df
		util.update_usrinput(df,'master_view', key='_id')
		resp = make_response('{"status": "ok"}')
		resp.headers['Content-Type'] = "application/json"
	except:
		resp = make_response('{"status": "error"}')
		resp.headers['Content-Type'] = "application/json"
		#print resp

	return resp;

@app.route('/api/get_id')
def getID():
	args = request.args
	enum = args['id']
	print enum
	output = util.read_mongo('dev', 'report_role_views', query={"ENUM": str(enum)})
	output = output.to_dict(orient='records')
	return jsonify(output);


@app.route('/api/compliant_inv_l4_view')
def compliantgetL4invexec():
	# you can change it to columns that need to be displayed..
	columns = [ 'L4', 'PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS', 'L3']
	index_column = "_id"
	collection = "L4platformcompliance"
	results =  dt.DataTablesServer(request, columns, index_column, collection).output_result()
	#print results
	# return the results as a string for the datatable
	return json.dumps(results)

@app.route('/api/compliant_inv_l3_view')
def compliantgetL3invexec():
	# you can change it to columns that need to be displayed..
	columns = [ 'L3','PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS']
	index_column = "_id"
	collection = "L3platformcompliance"
	results =  dt.DataTablesServer(request, columns, index_column, collection).output_result()
	#print results
	# return the results as a string for the datatable
	return json.dumps(results)

@app.route('/reports/l3_exec_export_all')
def l3_exec_export_all():
	l3exec = util.read_mongo('dev', 'L3platformcompliance')
	l3exec = l3exec[['L3','PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS']]
	resp = make_response(l3exec.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=l3executivereport.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp

@app.route('/reports/l4_exec_export_all')
def l4_exec_export_all():
	l4exec = util.read_mongo('dev', 'L4platformcompliance')
	l4exec = l4exec[['L3','PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS','L4']]
	resp = make_response(l4exec.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=l4executivereport.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp

@app.route('/reports/userinventory')
def user_inventory__export_all():
	args = request.args
	print args
	enum = args['enum']
	userinventory = util.read_mongo('dev', 'userinventory',{'ENUM':enum})
	print userinventory
	userinventory = userinventory[[ 'NAME', 'PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS']]
	resp = make_response(userinventory.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=myinventory.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp

@app.route('/reports/business_works_report')
def export_businessworks():
	l3exec = util.read_mongo('dev', 'master_view',{'PLATFORM_NAME': 'BusinessWorks' })
	l3exec = l3exec[['APP_CODE', 'SERVER_NAME','CURRENT_VERSION','STRATEGY','DATE','ENVIRONMENT','CURRENCY','COMMENTS','APP_NAME','L3_ORG', 'L3', 'L4','L5', 'APP_CUSTODIAN','LAST_UPDATE']]
	resp = make_response(l3exec.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=BusinessWorks.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp

@app.route('/reports/weblogic_report')
def export_weblogic():
	l4exec = util.read_mongo('dev', 'master_view',{'PLATFORM_NAME': 'WebLogic' })
	l4exec = l4exec[['APP_CODE', 'SERVER_NAME','CURRENT_VERSION','STRATEGY','DATE','ENVIRONMENT','CURRENCY','COMMENTS','APP_NAME','L3_ORG', 'L3', 'L4','L5', 'APP_CUSTODIAN','LAST_UPDATE']]
	resp = make_response(l4exec.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=WebLogic.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp


@app.route('/api/gtinvs')
def getGtiInvs():
		output = util.read_mongo(db='dev', collection='gtiinvs')
		output.columns = [x.lower() for x in output.columns]
		output = output.replace(np.nan, '', regex=True)
		output = output.to_dict(orient='records')
		return jsonify({
			'summary':{
					'total': len(output),
					'source': 'new_portal',
						},
					'aaData':output
		})


@app.route('/api/compliant_inventory_table')
def compliant_get_myinventory():
	columns = [ 'ENUM', 'PLATFORM_NAME', 'TOTALSERVERS', 'COMPLIANT_SERVERS', 'APPROACHING_NON_COMPLIANT_SERVERS', 'NON_COMPLIANT_SERVERS']
	index_column = "_id"
	collection = "userinventory"
	results =  dt.DataTablesServer(request, columns, index_column, collection).output_result()
	#print results
	# return the results as a string for the datatable
	return json.dumps(results)

@app.route('/reports/export_all')
def expot_all():
	df_1 = util.read_mongo('dev', 'master_view')
	df_1 = df_1[[ 'APP_CODE', 'SERVER_NAME', 'PLATFORM_NAME' ,'MIGRATION_ELIGIBILITY','END_SUPPORT', 'CURRENT_VERSION', 'ENVIRONMENT', 'APP_NAME', 'L3_ORG', 'L3', 'L4', 'L5', 'TYPE', 'SOURCE', 'DB_COUNT', 'DATE', 'APP_CUSTODIAN','COMMENTS','STRATEGY','INSTANCE_NM']]
	resp = make_response(df_1.to_csv(index=False))
	resp.headers["Content-Disposition"] = "attachment; filename=all_invs.csv"
	resp.headers["Content-Type"] = "text/csv"
	return resp

@app.route('/api/daily_digest')
def daily_digest():
		args = request.args
		ide = args['identifier']
		print ide
		output = util.read_mongo('dev', 'daily_digest', query={"identifier" : ide})
		output.columns = [x.lower() for x in output.columns]
		output = output.replace(np.nan, '', regex=True)
		if ide == 'per_l3' :
			output = output[['name','currency']].set_index('name').T.to_dict()
		else:
			output = output.set_index('platform_name').T.to_dict()
		return jsonify({
			'summary':{
					'total': len(output),
					'source': 'new_portal',
						},
					'results':output
		})

@app.route('/api/gtinvs_table')
def get():
	# you can change it to columns that need to be displayed..
	columns = [ 'PRODUCT', 'CR_NUMBER', 'GTI_TOP_TEN','FULL_VERSION',"VERSION",'EOL','PLATFORM', 'L5', 'REGION_TOP_TEN', 'REGION', 'TOWER','STANDARD', 'IIPM_NAME'	]
	index_column = "_id"
	# cange this to the collection you are tragetng...
	collection = "gtiinvs"
	# creating the object with its attributes...
	results =  dt.DataTablesServer(request, columns, index_column, collection).output_result()
	#print results
	# return the results as a string for the datatable
	return json.dumps(results)

@app.route('/api/getFaq')
def getAllQuestion():
	output = util.read_mongo(db='dev',collection = 'FAQ',no_id=True, sort = True)
	result = output.to_json(orient = 'records')
	return result

@app.route('/api/insertFaq', methods=['POST'])
def insertQuestion():
	try:
		print "enter insert function"
		json_data = request.get_json()

		if util.checkFaqExist('dev','FAQ',"questionNoString",json_data["questionNoString"]):
		   return jsonify(status='OK',message="existed")
		else:
		 df = json_normalize(json_data)
		 util.insert_mongo(df,'FAQ')
		 return jsonify(status='OK',message="inserted")

	except Exception, e:
		return jsonify(status='ERROR',message=str(e))


@app.route('/api/updateFaq', methods=['POST'])
def updateQuestion():
	try:
		json_data = request.json;
		msg = util.update_faq('dev',json_data,'FAQ',"questionNoString")
		return jsonify(status='OK',message=msg)
	except Exception, e:
		return jsonify(status='ERROR',message=str(e))

@app.route('/api/deleteFaq', methods =['POST'])
def deleteQuestion():
	try:
		json_data = request.json;
		util.delete_faq('dev',json_data,'FAQ','questionNoString')
		return jsonify(status='OK',message='deletion successful')
	except Exception, e:
		return jsonify(status='ERROR',message=str(e))

@app.route('/api/L3platformcompliance')
def platform_comp():
	args = request.args
	l3 = args['l3']
	#print l3
	output = util.read_mongo('dev', 'L3platformcompliance', query={'L3':l3})
	output = output.replace(np.nan, '', regex=True)
	output = output.set_index('PLATFORM_NAME').T.to_dict()
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})

@app.route('/api/platform_compliance')
def platform_compliance():
	output = util.read_mongo('dev', 'platformcompliance')
	output = output.replace(np.nan, '', regex=True)
	output = output.set_index('PLATFORM_NAME').T.to_dict()
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})


@app.route('/api/L3compliance')
def l3_comp():
	output = util.read_mongo('dev', 'L3compliance')
	output = output.replace(np.nan, '', regex=True)
	output = output.set_index('L3').T.to_dict()
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})

@app.route('/api/L3_currency_compliance')
def l3_currency_comp():
	output = util.read_mongo('dev', 'L3platformcompliance')
	output.columns = [x.lower() for x in output.columns]
	output = output.replace(np.nan, '', regex=True)
	output = output.to_dict(orient='records')
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})

@app.route('/api/L4_currency_compliance')
def l4_currency_comp():
	args = request.args
	l3 = args['l3']
	output = util.read_mongo('dev', 'L4platformcompliance',query={'L3':l3})
	output.columns = [x.lower() for x in output.columns]
	output = output.replace(np.nan, '', regex=True)
	output = output.to_dict(orient='records')
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})


@app.route('/api/myinventory')
def my_inventory():
	args = request.args
	enum = args['enum']
	output = util.read_mongo('dev', 'userinventory', {'ENUM': enum})
	output = output.replace(np.nan, '', regex=True)
	output = output.set_index('PLATFORM_NAME').T.to_dict()
	return jsonify({
		'summary':{
				'total': len(output),
				'source': 'new_portal',
					},
				'results':output
	})


class invs(Resource):
	   def get(self):
		args = request.args
		#print (args) # For debugging
		appCode = str(args['app_code']).upper()
		platform = str(args['platform']).upper()
		print appCode
		output = []
		if platform == 'ALL':
			output = util.read_mongo('dev', 'master_view', query={"APP_CODE" :appCode})
		else:
			output = util.read_mongo('dev', 'master_view', query={"APP_CODE" :appCode, "PLATFORM_NAME":platform })
		output.columns = [x.lower() for x in output.columns]
		output = output.replace(np.nan, '', regex=True)
		output = output.to_dict(orient='records')
		if len(output) > 0:
			return jsonify({
				'summary':{
						'total': len(output),
						'sources': 'TBD',
							},
						'results':output,
						'status' : 'OK'
						})
		else:
			 return jsonify({
						'results':[],
						 'status' : 'ZERO_RESULTS'
						})




@app.after_request
def after_request(response):
	response.headers.add('Access-Control-Allow-Origin', '*')
	response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
	response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
	return response


api.add_resource(invs, '/api/invs') # Route_3
api.add_resource(ls, '/api/ls') # Route_6


if __name__ == '__main__':
	   app.run( host='127.0.0.1', port=5001)
#http://127.0.0.1:5000

# In[ ]: