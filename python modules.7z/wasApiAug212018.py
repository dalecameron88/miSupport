import requests
import urllib2, base64
import pandas as pd
import utilites as util
import pandas as pd
from pymongo import MongoClient
import pyodbc
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json


cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )
						 
#Read the csv file and prepare the data
def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_SUPPORT, chargeable_PVU as chargeable_PVUFRMMDW, status AS STATUS from mw_instance WHERE software_component='WAS' AND STATUS = 'Active' ")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('WASDATAFRMMDWsept132018.csv',encoding='utf-8')
    print 'This is MDW Data from database'
    #print data['SERVER_NAME']
    return data;


def getWasApiData():
    request = urllib2.Request("http://pt00.devfg.rbc.com/mdwAPI.php")
    base64string = base64.b64encode('%s' % ('pt00@admin'))
    request.add_header('Content-Type', 'application/json')
    request.add_header('Cookie', 'PHPSESSID=co4nbaooa5pq1hh252621gsuq8')
    #request.add_header("Authorization", "Basic %s" % base64string)   
    result = urllib2.urlopen(request)
    wasApiData = json.load(result)
    keys = []
    vals = []
    for d in wasApiData:
        val = []
        for k,v in d.items():
            keys.append(k)
            val.append(v)
        vals.append(val)

    wasApiData = pd.DataFrame([v for v in vals], columns=list(dict.fromkeys(keys)))
    #wasApiData.to_csv('WAS_PATCH_INFO.csv', encoding='utf-8', index=False)
    wasApiData['HostName'] = wasApiData['HostName'].apply(lambda x: x.split('.')[0])#df['a'].apply(lambda x: x.split('-')[0])
    wasApiData['WAS Version'] = wasApiData['WAS Version'].str.extract('(\d+)', expand=False)#wasApiData['WAS Version'] = re.sub('[^0-9]','', wasApiData['WAS Version'])
    wasApiData['WAS Version'] = wasApiData['WAS Version'].astype(int)
    wasApiData['WAS Version'] = wasApiData['WAS Version']/10
    wasApiData['WAS Version'] = wasApiData['WAS Version'].map('{:.2g}'.format)
    #print wasApiData['WAS Version']
    wasApiData['WAS Version'] = wasApiData['WAS Version'].replace(['0.8'], '8.0')
    wasApiData['WAS Version'] = wasApiData['WAS Version'].replace(['0.7'], '7.0')
    wasApiData['WAS Version'] = wasApiData['WAS Version'].replace(['8.5'], '8.5.5')
    #print wasApiData['WAS Version']
    wasApiData.columns = ['APP_CODE', 'SERVER_NAME', 'Chargeable PVU', 'WAS Version', 'WAS Path', 'WAS Latest Patch Date', 'Scrape Date']
    wasApiData.to_csv('WAS_PATCH_INFO.csv', encoding='utf-8', index=False)
    return wasApiData


#Merge with IIPM to get the server details, if it is not found in IIPM drop the server
	
def wasapi_final():
    #iipm = util.read_mongo('devuser','iipm') #Read IIPM for the correct data  
    data = read_file(); #Prepare the data for processing
    #print data['SERVER_NAME']
    #data = pd.merge(data, servers, on='SERVER_NAME', how='left') #Merge the data to check for matches
    #print "size of file after mergin with servers(to get correct app code and env):"
    wasApiData = getWasApiData()
    wasApiData.drop(['WAS Latest Patch Date', 'WAS Latest Patch Date', 'Scrape Date'], axis=1)
    data = pd.merge(data, wasApiData, how='right', on=['APP_CODE','SERVER_NAME'])#pd.merge(data, wasApiData, on=['APP_CODE', 'SERVER_NAME']) #--- how='left', left_on=['A_c1','c2']-----data = wasApiData.merge(data, on=['APP_CODE', 'SERVER_NAME']) ##Merge the new data with the old data in order to preserve the comments, date, strategy, and comments
    data.drop_duplicates('SERVER_NAME', inplace=True)
    data.drop('WAS Latest Patch Date', axis = 1, inplace = True)
    data.drop('Scrape Date', axis = 1, inplace = True)
    data['STATUS'] = data['STATUS'].fillna('Decommissioned') #data.loc[data['STATUS'] == 'NAN', 'STATUS'] = 'Decommissioned' #Used to fix missing versions #df['column']=df['column'].fillna(value)
    print data['STATUS']
    data.to_csv('TESTWASAPIAug312018.csv',encoding='utf-8',index=None)
    return data;
    #if __name__ == '__main__':
data = wasapi_final()
#datafrmmdw = read_file()