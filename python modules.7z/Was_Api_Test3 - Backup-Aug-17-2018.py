import requests
import json
import urllib2, base64
import pandas as pd

request = urllib2.Request("http://pt00.devfg.rbc.com/mdwAPI.php")
base64string = base64.b64encode('%s' % ('pt00@admin'))
request.add_header('Content-Type', 'application/json')
request.add_header('Cookie', 'PHPSESSID=q4elub2gdv8n4asctci2va72p9')   
result = urllib2.urlopen(request)
data = json.load(result)
keys = []
vals = []
for d in data:
    val = []
    for k,v in d.items():
        keys.append(k)
        val.append(v)
    vals.append(val)

df = pd.DataFrame([v for v in vals], columns=list(dict.fromkeys(keys)))
df.to_csv('WAS_PATCH_INFO.csv', encoding='utf-8', index=False)
print df


#    print key, value
	
#result_list = [str(v) for k,v in data.items()]
#result_list = [[int(v) for k,v in d.items()] for d in qs]
#print result_list

#result_list = []
#for d in data:
#    result_list.append([str(v) for k,v in d.items()])
#print d

#print "%s %s: %s\n"%(item['HostName'],item['App Code'],item['WAS Version']) for item in data
#print data[]
#endpoint = "http://pt00.devfg.rbc.com/mdwAPI.php"
#url = "http://pt00.devfg.rbc.com/mdwAPI.php"
#data = {"HostName":"uasigad01.devfg.rbc.com"}
#headers = {"Authorization":"PHPSESSID=1cpntv00kq6t35gvlaeutfra8v"}

#r = requests.post(endpoint,data=data,headers=headers)
#data = json.load()
#print r

#req = urllib2.Request(url)
#req.add_header('Content-Type', 'application/json')
#req.add_header('Cookie', 'PHPSESSID=1cpntv00kq6t35gvlaeutfra8v')
#response = urllib2.urlopen(req)
#res = json.dumps(response)

#import urllib2
#import simplejson

#auth_handler = urllib2.HTTPBasicAuthHandler()
#auth_handler.add_password(uri='http://pt00.devfg.rbc.com/mdwAPI.php',
#                          passwd='pt00@admin')
#opener = urllib2.build_opener(auth_handler)
#urllib2.install_opener(opener)
#response1 = urllib2.urlopen('http://pt00.devfg.rbc.com/mdwAPI.php')
#response2 = urllib2.urlopen("http://pt00.devfg.rbc.com/mdwAPI.php")
#data1 = simplejson.load(response1)
#data2 = simplejson.load(response2)
#print data1
#print res
# => {'content': 'Hello World!', 'success': True}




#  
# read the data from the URL and print it
#
#import urllib2

#def main():
# open a connection to a URL using urllib2
#   webUrl = urllib2.urlopen("https://www.youtube.com/user/guru99com")
  
#get the result code and print it
#   print "result code: " + str(webUrl.getcode()) 
  
# read the data from the URL and print it
#   data = webUrl.read()
#   print data
 
#if __name__ == "__main__":
#  main()
