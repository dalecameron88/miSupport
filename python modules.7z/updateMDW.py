@app.route('/api/UpdateServer', methods=['POST'])
def update_server():

            incoming = request.get_json()
            print incoming #obtain the incokming data

             ##Check if there is a key in the incoming json object if not present set it to 0
            if 'server_name' in incoming:
                 server_name = request.json['server_name']
            else:
                 server_name = ""

            if 'software_component' in incoming:
                 software_component = request.json['software_component']
            else:
                 software_component = ""

            if 'mv_app_code' in incoming:
                mv_app_code = request.json['mv_app_code']
            else:
                mv_app_code = ''

            if 'app_app_code' in incoming:
                 app_app_code = request.json['app_app_code']
            else:
                app_app_code = ''

            if 'service_window_cycle' in incoming:
                    service_window_cycle = request.json['service_window_cycle']
            else:
                    service_window_cycle = ''

            if 'software_component_version' in incoming:
                software_component_version = request.json['software_component_version']
            else:
                software_component_version = ''

            if 'end_of_support' in incoming:
                end_of_support = request.json['end_of_support']
            else:
                end_of_support = ''

            if 'install' in incoming:
                install = request.json['install']
            else:
                install = ''

            if 'patch' in incoming:
                patch = request.json['patch']
            else:
                patch = ''

            if 'capped' in incoming:
                capped = request.json['capped']
            else:
                capped = ''

            if 'entitled_capacity' in incoming:
                entitled_capacity = request.json['entitled_capacity']
            else:
                entitled_capacity = ''

            if 'virtual_processor' in incoming:
                virtual_processor = request.json['virtual_processor']
            else:
                virtual_processor = ''

            if 'pvu_core' in incoming:
                pvu_core = request.json['pvu_core']
            else:
                pvu_core = ''

            if 'chargeable_core' in incoming:
                chargeable_core = request.json['chargeable_core']
            else:
                chargeable_core = ''

            if 'chargeable_pvu' in incoming:
                chargeable_pvu = request.json['chargeable_pvu']
            else:
                chargeable_pvu = ''

            if 'version' in incoming:
                version = request.json['version']
            else:
                version = ''

            if 'platform' in incoming:
                platform = request.json['platform']
            else:
                platform = ''

            if 'os' in incoming:
                os = request.json['os']
            else:
                os = ''

            if 'environment' in incoming:
                environment = request.json['environment']
            else:
                environment = ''

            if 'min_memory' in incoming:
                min_memory = request.json['min_memory']
            else:
                min_memory = ''

            if 'max_memory' in incoming:
                max_memory = request.json['max_memory']
            else:
                max_memory = ''

            if 'qmgr_name' in incoming:
                qmgr_name = request.json['qmgr_name']
            else:
                qmgr_name = ''

            if 'qmgr_port' in incoming:
                qmgr_port = request.json['qmgr_port']
            else:
                qmgr_port = ''

            if 'attestation' in incoming:
                attestation = request.json['attestation']
            else:
                attestation = ''

            if 'install_type' in incoming:
                install_type = request.json['install_type']
            else:
                install_type = ''

            if 'ha_version' in incoming:
                ha_version = request.json['ha_version']
            else:
                ha_version = ''

            if 'ha_fqdn' in incoming:
                    ha_fqdn = request.json['ha_fqdn']
            else:
                    ha_fqdn = ''

            if 'standby_mode' in incoming:
                    standby_mode = request.json['standby_mode']
            else:
                    standby_mode = ''


            if 'location' in incoming:
                    location = request.json['location']
            else:
                    location = ''

            if 'status' in incoming:
                    status = request.json['status']
            else:
                    status = ''

            if 'comments' in incoming:
                    comments = request.json['comments']
            else:
                    comments = ''

            if 'server_id' in incoming:
                    server_id = request.json['server_id']
            else:
                    server_id = ''

            if 'non_chargeable' in incoming:
                        non_chargeable = request.json['non_chargeable']
            else:
                        non_chargeable = ''

            if 'last_edited_by' in incoming:
                        last_edited_by = datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' By: ' + request.json['last_edited_by']
            else:
                        last_edited_by = ''

        #    cursor.execute("UPDATE mw_instance SET server_name = ?, software_component= ? where srvr_inty_id = ?", server_name,software_component,server_id)

            cursor.execute("UPDATE mw_instance SET server_name = ?,software_component = ?,mv_app_code = ?,app_app_code = ?,software_component_version = ?,service_window_cycle = ?, end_of_support = ?,install = ?,patch = ?,capped = ?,entitled_capacity = ?,virtual_processor = ?,pvu_core = ?,chargeable_core = ?,chargeable_pvu = ?,version = ?,platform = ?,os = ?,environment = ?,min_memory = ?,max_memory = ?,qmgr_name = ?,qmgr_port = ?,attestation = ?,install_type = ?,ha_version = ?,ha_fqdn = ?,standby_mode = ?,location = ?,status = ?,comments = ?, non_chargeable = ?, last_edited_by = ? where srvr_inty_id = ?", server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments,non_chargeable,last_edited_by,server_id)

            try:
                cnxn.commit()
                resp = '201'
            except pyodbc.Error as ex:
                sqlstate = ex.args[0] + ex.args[1]
                print(sqlstate)
                resp = '404'
            cnxn.close
            return resp
