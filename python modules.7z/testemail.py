"""The first step is to create an SMTP object, each object is used for connection
with one server."""

import smtplib
import psutil
server = smtplib.SMTP('labmailer.devfg.rbc.com', 25)

#Send the mail
msg = "Hello!" # The /n separates the message from the headers


SUBJECT = "Hello!"

TEXT = "This message was sent with Python's smtplib."

message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)

server.sendmail("autointake@sterbc.com", ["autointake@sterbc.com"], message)
server.quit()


for pid in psutil.pids():
    p = psutil.Process(pid)
    if p.name() == "httpd.exe":
        print("Apache is running")


import logging
logging.basicConfig(filename='example.log',level=logging.DEBUG)
logging.debug('This message should go to the log file')
logging.info('So should this')
logging.warning('And this, too')
###########################################################################

import os
import sys
import traceback
import re
import smtplib
import getpass


#!/usr/bin/env python


import smtplib

class Gmail(object):
    def __init__(self, email, password):
        self.email = email
        self.password = password
        self.server = 'smtp.gmail.com'
        self.port = 587
        session = smtplib.SMTP(self.server, self.port)        
        session.ehlo()
        session.starttls()
        session.ehlo
        session.login(self.email, self.password)
        self.session = session

    def send_message(self, subject, body):
        ''' This must be removed '''
        headers = [
            "From: " + self.email,
            "Subject: " + subject,
            "To: " + self.email,
            "MIME-Version: 1.0",
           "Content-Type: text/html"]
        headers = "\r\n".join(headers)
        self.session.sendmail(
            self.email,
            self.email,
            headers + "\r\n\r\n" + body)


gm = Gmail('dalecameron88@gmail.com', 'D1c#ameron')

gm.send_message('Subject', 'Message')