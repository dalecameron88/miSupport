https://stackoverflow.com/questions/46423499/python3-http-error-302-while-using-urllib

http://pt00.devfg.rbc.com/mdwAPI.php?password={$pt00@admin}

https://www.pythonforbeginners.com/requests/using-requests-in-python

http://docs.python-requests.org/en/master/user/authentication/




HTTP ERROR 302
https://stackoverflow.com/questions/46423499/python3-http-error-302-while-using-urllib
https://stackoverflow.com/questions/4098702/python-urllib2-urlopen-returning-302-error-even-though-page-exists