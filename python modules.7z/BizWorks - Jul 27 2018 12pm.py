import pandas as pd
import utilites as util
import pyodbc
from itertools import chain
import numpy as np
import logic as l

#mdw DB connection string
cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server # df.set_index('book').authors.str.split(',', expand=True).stack().reset_index('book')
def merge_iipm(data,iipm):
    data['APP_CODE'] = data['APP_CODE'].astype('str')
    data['APP_CODE'] = data['APP_CODE'].str.split(',', expand=True)
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data[data['APP_CODE'].isnull()].to_csv('BusinessWorks_servers_missing.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Obtain the old data
def curr_platform(platform='BusinessWorks'):
    data = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['APP_CODE','DATE','SERVER_NAME','COMMENTS','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    #check data > file
    #data.to_csv("output.csv", sep=',', encoding='utf-8')
    return data

def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT grouped_app_code as APP_CODE, srvr_inty_id as srvr_inty_id, server_name as SERVER_NAME,environment as ENVIRONMENT,software_component_version as VERSION, version as CURRENT_VERSION, PLATFORM as PLATFORM, END_OF_SUPPORT as END_OF_SUPPORT from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active' ")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('BissnessWorksDATAFRMMDW123.csv',encoding='utf-8')
    return data;

def prep_data():
    data = read_file()
    data['HSP_LINK'] = 'https://hsp-prod.fg.rbc.com/welcome'
    data['CURRENCY'] = data.apply(l.currency('businessworks'),axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    data['END_SUPPORT'] = data.apply(l.EOL('businessworks'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['DB_COUNT'] = ""
    data['SOURCE'] = "N/A"
    data['TYPE'] = "N/A"
    data['PLATFORM_NAME'] = "BusinessWorks"
    data['PLATFORM'] = data['PLATFORM']
    data['INSTANCE_NM'] = "N/A"
    data['END_OF_SUPPORT'] = data['END_OF_SUPPORT']
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].astype(str)
    data['APP_CODE'] = data['APP_CODE'].astype(str)
    data['APP_CODE'].replace(np.nan, '000', regex=True)
    data['APP_CODE'] = data['APP_CODE'].str.split(',')
    lens = list(map(len, data['APP_CODE']))
    res = pd.DataFrame({'SERVER_NAME': np.repeat(data['SERVER_NAME'], lens),
                    'APP_CODE': list(chain.from_iterable(data['APP_CODE'])),
                    'APP_CODE': list(chain.from_iterable(data['APP_CODE'])),
                    'END_OF_SUPPORT': np.repeat(data['END_OF_SUPPORT'], lens),
					'CURRENT_VERISON': np.repeat(data['CURRENT_VERSION'], lens),
					'SERVER_NAME': np.repeat(data['SERVER_NAME'], lens)})					
    print res
    #data = pd.concat([data, res])
    data = data.merge(res,on=['SERVER_NAME','APP_CODE'],how='inner')
    print 'This is the Grouped AppCode Output'
    print data
    #print data2
    return data

#df2 = pd.DataFrame([[5, 6], [7, 8]], columns=list('AB'))
def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_business_works_temp'].drop()
    util.insert_mongo(master, 'master_business_works_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'BusinessWorks'})
    util.insert_mongo(data, 'master_view')


def businessworksfinal():
    #get data from iipm table
    iipm = util.read_mongo('dev', 'iipm')
    db = util._connect_mongo()
    #get data from csv file
    data = prep_data()
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data,iipm)
    print len(data)
    #get data from master_view with columnes ['DATE','SERVER_NAME','COMMENTS','STRATEGY']
    oldBusinessWorks = curr_platform()
    data = data.merge(oldBusinessWorks,on=['SERVER_NAME','APP_CODE'],how='left')
    #data.drop_duplicates(['SERVER_NAME','APP_CODE'],inplace=True)
    #print "size of file after dropping duplicates"
    print len(data)

    #update master_business_works_temp with old master_view;
    #update master_view(BusinessWorks) with merged data
    #shipp(data)
    return data;

if __name__ == '__main__':
    data = businessworksfinal()
data.to_csv('TESTBizWorks123.csv',encoding='utf-8',index=None)