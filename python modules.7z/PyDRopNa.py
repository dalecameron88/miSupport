from pandas import DataFrame as df

In [2]: mydf = df([1.1, 1.1, 1.1]).T

In [3]: arow2 = [2.2, 2.2, 2.2]

In [4]: mydf.loc[len(mydf)] = arow2

In [5]: print(mydf)  
     0    1    2  
0  1.1  1.1  1.1  
1  2.2  2.2  2.2

data=pd.concat([data, data1])
    columns = ['APP_CODE']
    data = data.replace(" ", pd.np.nan).dropna(axis=0, how='any', subset=columns).fillna(" ").astype(str)



One line hack using .dropna()

import pandas as pd

df = pd.DataFrame({'A':[1,4,6,0],'B':[2,4,8,4],'C':[5,0,4,2]})
print df
   A  B  C
0  1  2  5
1  4  4  0
2  6  8  4
3  0  4  2

columns = ['A', 'C']
df = df.replace(0, pd.np.nan).dropna(axis=0, how='any', subset=columns).fillna(0).astype(int)

print df
   A  B  C
0  1  2  5
2  6  8  4



columns = ['APP_CODE', 'CURRENT_VERSION']
df = df.replace(' ', pd.np.nan).dropna(axis=0, how='any', subset=columns).fillna(' ').astype(int)



https://stackoverflow.com/questions/44723183/set-value-to-an-entire-column-of-a-pandas-dataframe