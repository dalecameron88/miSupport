Python Split explode pandas dataframe string entry to separate rows
df = pd.DataFrame([[1, 2], [3, 4]], columns=list('AB'))
>>> df

>> df2 = pd.DataFrame([[5, 6], [7, 8]], columns=list('AB'))
>>> df.append(df2)



chrom   exonStart     exonEnds      name
chr1    100,200,300   110,210,310   gen1
chr1    500,700       600,800       gen2
chr2    50,60,70,80   55,65,75,85   gen3

pd.DataFrame([ [c, s, e, n] for c, S, E, n in df.itertuples(index=False) for s, e in zip(S.split(','), E.split(','))], columns=df.columns)



import numpy as np
from itertools import chain

df['exonStart'] = df['exonStart'].str.split(',')
df['exonEnds'] = df['exonEnds'].str.split(',')

lens = list(map(len, df['exonStart']))

res = pd.DataFrame({'chrom': np.repeat(df['chrom'], lens),
                    'exonStart': list(chain.from_iterable(df['exonStart'])),
                    'exonEnds': list(chain.from_iterable(df['exonEnds'])),
                    'name': np.repeat(df['name'], lens)})

print(res)


res = pd.DataFrame({'chrom': np.repeat(df['chrom'], lens), 'exonStart': list(chain.from_iterable(df['exonStart'])), 'exonEnds': list(chain.from_iterable(df['exonEnds'])), 'name': np.repeat(df['name'], lens)})