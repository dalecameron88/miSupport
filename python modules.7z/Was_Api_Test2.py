# -*- coding: utf-8 -*-  
# imports  
import pymysql  

# open connection to the database  
conn = pymysql.connect(host='10.241.131.102',  
                       port=3306,  
                       user='test123',  
                       passwd='test123',  
                       db='was',  
                       charset='utf8')  
cur = conn.cursor()  

sql = "SELECT * FROM inventory"  
cur.execute(sql)  

# close connection to the database
cur.close()  
conn.close(  )