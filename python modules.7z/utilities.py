import io
import pyodbc
import json
import time
import urllib2
import pymongo
#import cx_Oracle
import numpy as np
import pandas as pd
import pandas.io.sql as psql
from datetime import datetime
from pymongo import MongoClient
from pandas.io.json import json_normalize
from bson import ObjectId




def _connect_mongo(host='10.211.146.78', port=27017, username="kriApp", password="passwordkriApp!", db='kri'):
    """ A util for making a connection to mongo """
    if username and password:
        mongo_uri = 'mongodb://%s:%s@%s:%s/%s' % (username, password, host, port, db)
        conn = MongoClient(mongo_uri)
    else:
        conn = MongoClient(host, port)

    return conn[db]

def _connect_oracel(username='USPLLBV0',password='RitpPBL17LB', host_port='oc11p0-scan.fg.rbc.com:1527/pl00_prod2'):
    """ A util for making a connection to mongo """
    con = cx_Oracle.connect('USPLLBV0/RitpPBL17LBV@oc11p0-scan.fg.rbc.com:1527/pl00_prod2');
    return con

def _connect_sql(username='SCON_INV_RO',password='Password1', host='SERVER=YKE0-D2K8SWN2\IN02'):
    """ A util for making a connection to sql database """
    cnxn = pyodbc.connect('Driver={SQL Server};'
                                'Server=YKE0-D2K8SWN2\IN02;'
                                'Database=DYKE_DBMonitor;'
                                'uid=SCON_INV_RO;pwd=Password1')
    return cnxn


def read_mongo(db, collection, query={}, host=None, port=27017, username=None, password=None, no_id=True, search='', sort = False):
    """ Read from Mongo and Store into DataFrame """
    # Connect to MongoDB
    db = _connect_mongo();

    # Make a query to the specific DB and Collection

    if (sort):
        cursor = db[collection].find(query).sort([("questionNoString", pymongo.DESCENDING)])
    elif not search:
        cursor = db[collection].find(query)
    else:
        cursor = db[collection].find(search)

    # Expand the cursor and construct the DataFrame
    df =  pd.DataFrame(list(cursor))
    if len(df)> 0:
        del df['_id']
    return df;

def read_oracel (sql):
    """ Read from oracel and Store into DataFrame """

    #connecting
    con = _connect_oracel()

    #reading sql as DataFrame...
    data = psql.read_sql(sql,con)
    data = pd.DataFrame(data)

    #closing connection
    con.close()

    return data;



def read_myops(query):
    """ Read from myOpps and Store into DataFrame """
    #requesting myOpps POST api with passing query json
    req = urllib2.Request('http://myops/api/reporting/DESexport/getDESdata')
    req.add_header('Content-Type', 'application/json')
    response = urllib2.urlopen(req, json.dumps(query))

    #reading the response
    data = response.read()


    #first time loading the the data and normalizng the source obj...
    data = json.loads(data)
    scrollID = data['scrollID']
    total = json_normalize(data['source'])
    query['scroll_id'] = str(scrollID)

    #requesting myOpps POST api with passing query json this time with query that has scroll_id
    req = urllib2.Request('http://myops/api/reporting/DESexport/getDESdata')
    req.add_header('Content-Type', 'application/json')
    response = urllib2.urlopen(req, json.dumps(query))

    checkSize = True;
    # keep scroling untill there is no data left (this is elasticsearch back-end)
    while checkSize:
        #reading the response
        data = response.read()

        #loading the the data and normalizng the source obj...
        response = urllib2.urlopen(req, json.dumps(query))
        data = json.loads(data)
        if len(data['source']) == 0:
            checkSize = False;

        if checkSize:
            data = json_normalize(data['source'])
            total = total.append(data, ignore_index=True)
    return total


def read_HSPALL():
    """ Read from HSP API and Store into DataFrame """

    #requesting HSP GET api with passing token given
    req = urllib2.Request('https://hsp-prod.fg.rbc.com/rs/forms/listMyOpenTickets?token=Qnwe5L1Sl8Q1OsXwyC/x7x5xPprcdYh2')
    response = urllib2.urlopen(req)
    data = response.read()

    #converting into dataframe...
    data = json.loads(data)
    data = pd.DataFrame(data['aaData'])

    return data;


def read_HSPFULL():
    """ Read from HSP API and Store into DataFrame (for each ticket full...) """
    objs = []
    #reading all hsps tickets open and getting the ids as a list...
    data = read_HSPALL();
    ids = data['id'].tolist();

    #itterating through ids to go to each respected ticket to get the full info...
    for elem in ids:
        #requesting HSP GET api with passing token given and id retrived...
        url = 'https://hsp-prod.fg.rbc.com/rs/forms/ticketDetails?token=Qnwe5L1Sl8Q1OsXwyC/x7x5xPprcdYh2&id='+ elem
        req = urllib2.Request(url)
        response = urllib2.urlopen(req)
        data = response.read()

        #converting into dataframe...
        data = json.loads(data)
        objs.append(data)
    data = pd.DataFrame(objs)
    return data;





def read_sql(sql,con):
    """ Read from oracel and Store into DataFrame """

    #con  = _connect_sql();
    #passing con and sql query to return result as DataFrame
    data = psql.read_sql(sql, con)

    #replacing all the null values with empty string
    data = data.replace(np.nan, '', regex=True)

    #closing connection
    con.close()

    return data


def insert_mongo(data,collection):
    """ A util for inserting mongo --kri db default--  """
    #bulk objs to be updated
    objs = []
    client = _connect_mongo()
    #table to be connected
    db = client[collection];
    for index, row in data.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));
        #print obj;
        #obj["LAST_UPDATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        objs.append(obj);
    db.insert(objs);
    print 'inserted...'

def remove_mongo(collName='master_view',itemName=''):
    """ A util for removeing from collection --kri db default--  """
    db = util._connect_mongo()
    coll = db[collName];
    coll.delete_many ({'PLATFORM_NAME':itemName});
    return itemName + ' removed from ' + collName

def update_mongo(data,collection,key='_id'):
    """ A util for updating mongo --kri db default--  """
    #bulk objs to be updated
    objs = []
    client = _connect_mongo()
    #table to be connected
    coll = client[collection];

    for index, row in data.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));
        #obj["LAST_UPDATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        coll.update({key : ObjectId(obj[key])}, {'$set': {'DATE': obj['DATE']}})

def upsert_mongo(data,collection,key='SERVER_NAME'):
    """ A util for updating mongo --kri db default--  """
    #bulk objs to be updated
    objs = []
    client = _connect_mongo()
    #table to be connected
    coll = client[collection];
    bulk = coll.initialize_unordered_bulk_op();

    for index, row in data.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));
        #obj["LAST_UPDATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        bulk.find({key : obj[key]}).upsert().update({'$set':obj})
    bulk.execute()
    print 'upserted..'


def checkFaqExist(db, collection,key, value):
    """A util for checking a record's existence based on a key's value"""
    #connect ot database
    client = _connect_mongo(db=db)
    table = client[collection];
    #check existence
    try:
        item = table.find({key:value})
    except Exception,e:
        return str(e)

    result = len(list(item))
    if result != 0:
        print("existed")
        return True
    else:
        print("new")
        return False



def update_faq(db, data, collection, field):
    """ A util for updating mongo based on a specific field(this field must be unique) """
    #connect to database
    client = _connect_mongo(db=db)
    table = client[collection];

    #update record
    if(data['newQuestionNoString'] == data['questionNoString']):
        #update an existing record(without questionNoString change, no order change)
        try:
            table.find_one_and_update({"questionNoString":data['questionNoString'] }, {"$set": {'title': data['title'], 'content': data['content'], 'questionNoString':data['newQuestionNoString']}})
            return "update successfully"
        except Exception,e:
            return str(e)
    else:
        #update an existing record(with questionNoString change, order change)
        result = checkExist(db=db, collection=collection,key='questionNoString',value=data['newQuestionNoString'])
        if result:
            #the newQuestionNO is occupied by other record
            return "existed"
        else:
            #the newQuestionNO is available
            try:
                table.find_one_and_update({field:data[field] }, {"$set": {'title': data['title'], 'content': data['content'], 'questionNoString':data['newQuestionNoString']}})
                return "update successfully"
            except Exception,e:
                return str(e)


def delete_faq(db, data, collection, field):
    """a util for deleting data based on an abject's specific field"""
    #connect to database
    client = _connect_mongo(db=db)
    table = client[collection];
    try:
        #delete record
        table.remove({field:data[field]})
        return "delete sucessfully"
    except Exception, e:
        return str(e)