import pandas as pd
from datetime import datetime, date
from dateutil.relativedelta import relativedelta

# coding: utf-8

# In[2]:


#Checks against the rows end support column and returns if it is compliant, not compliant or approaching compliance - datetime.datetime.strptime("21/12/2008", "%d/%m/%Y").strftime("%Y-%m-%d")
#Checks against the rows end support column and returns if it is compliant, not compliant or approaching compliance
def compliance_check(row):
        eighteenmonths = datetime.now() + relativedelta(months=+18)

        if row['END_OF_SUPPORT'] == 'TBD':
           row['END_OF_SUPPORT'] =  datetime.strptime('2030 01 01', '%Y %m %d')
        elif row['END_OF_SUPPORT'] == 'N/A' or row['END_OF_SUPPORT'] == 'EOL':
           row['END_OF_SUPPORT'] = datetime.strptime('2010 01 01', '%Y %m %d')
        else:
           row['END_OF_SUPPORT'] = datetime.strptime(row['END_OF_SUPPORT'], "%Y/%m/%d").strftime("%Y-%m-%d")

        if row['END_OF_SUPPORT'] < datetime.now().strptime("04/07/2018", "%d/%m/%Y").strftime("%Y-%m-%d"):
           return 'Non Compliant (EOL)'
        elif row['END_OF_SUPPORT'] > datetime.now().strftime("%Y/%m/%d") and row['END_OF_SUPPORT'] < eighteenmonths.strftime("%Y/%m/%d"):
           return 'Approaching Non Compliant (EOL within 18mths)'
        elif row['END_OF_SUPPORT'] > eighteenmonths.strptime("04/07/2018", "%d/%m/%Y").strftime("%Y-%m-%d"):
           return 'Compliant (EOL 18mths+)'


def currency_BUSINESSWORKS(row):
    if float(row['CURRENT_VERSION']) == 5.11 :
        return 'N-1'

    elif float(row['CURRENT_VERSION']) == 5.13:
         return 'N'
    else:
        return 'N/A'


def currency_WAS(row):
    """A util to parse operatingSystem name and return the version """
    if str(row['CURRENT_VERSION']) == 8.5 :
        return 'N'

    elif str(row['CURRENT_VERSION']) == 8.0:
         return 'N-1';

    elif str(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif str(row['CURRENT_VERSION']) < 8.0:
        return 'N-2+';


    else:
        return 'N/A'

def currency_MQ(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 8.0 :
        return 'N'

    elif float(row['CURRENT_VERSION']) == 7.5:
         return 'N-1';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) < 7.5:
        return 'N-2+';


    else:
        return 'N/A'
        
def currency_JBOSS(row):
    """A util to parse operatingSystem name and return the version """
    if str(row['VERSION']) == 'EAP 7.0.8' :
        return 'N'

    elif str(row['VERSION']) == 'EAP 6.2':
         return 'N-1';
    
    elif str(row['VERSION']) == 'EAP 6.3.3':
         return 'N-1';
    
    elif str(row['VERSION']) == 'EAP 6.4.9':
         return 'N-1';
         
    elif str(row['VERSION']) == '5':
        return 'N-2+';

    elif str(row['VERSION']) < '4':
        return 'N-2+';


    else:
        return 'N/A'        

def currency_DB2(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) >= 11.0:
        return 'N'

    elif float(row['CURRENT_VERSION']) == 10.5:
         return 'N-1';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';


    elif float(row['CURRENT_VERSION']) < 10.5:
        return 'N-2+';


    else:
        return 'N/A'

def currency_AIX(row):
    """A util to parse operatingSystem name and return the version """
    if(str(row['CURRENT_VERSION'])):
        if (row['CURRENT_VERSION']) == 'None':
            return 'N/A'
        elif float(row['CURRENT_VERSION']) == 7.2 :
            return 'N'
        elif float(row['CURRENT_VERSION']) == 7.1:
            return 'N-1';
        elif float(row['CURRENT_VERSION']) == 0.0:
            return 'N/A';
        elif float(row['CURRENT_VERSION']) < 7.1:
            return 'N-2+';
        else:
            return 'N/A';
    else:
        return 'N/A';

def currency_SOLARIS(row):

    """A util to parse operatingSystem name and return the version """
    if(str(row['CURRENT_VERSION'])):
        if float(row['CURRENT_VERSION']) == 11:
            return 'N'
        elif float(row['CURRENT_VERSION']) == 10:
            return 'N-1';
        else:
            return 'N/A';
    else:
        return 'N/A';

def currency_REDHAT(row):
    """A util to parse operatingSystem name and return the version """
    print row
    if ((row['CURRENT_VERSION']) == 'None'):
        return 'N/A'

    elif float(row['CURRENT_VERSION']) >= 7.0:
        return 'N'

    elif float(row['CURRENT_VERSION']) >= 6.7:
        return 'N-1';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) < 6.7:
        return 'N-2+';

    else:
        return 'N/A';

def currency_ORACLE(row):
    """A util to parse operatingSystem name and return the version """
    print row
    if row['CURRENT_VERSION'] == "12c" :
        return 'N'

    elif row['CURRENT_VERSION'] == "11g":
        return 'N-1';

    else:
        return 'N/A';


def currency_WINDOWS(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 2016 :
        return 'N'

    elif float(row['CURRENT_VERSION']) == 2012:
        return 'N-1';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) <= 2008:
        return 'N-2+';

    else:
        return 'N/A';


def currency_SQL(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 2016 :
        return 'N'

    elif float(row['CURRENT_VERSION']) == 2014 :
        return 'N'

    elif float(row['CURRENT_VERSION']) == 2012:
        return 'N-1';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) <= 2008:
        return 'N-2+';

    else:
        return 'N/A';

def EOL_BUSINESSWORKS(row):
    if float(row['CURRENT_VERSION']) == 5.11:
            return '2018-12-31'
    elif float(row['CURRENT_VERSION']) == 5.13:
            return 'TBD';
    else:
            return 'N/A'

def EOL_MQ(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 8.0 :
        return 'TBD';

    elif float(row['CURRENT_VERSION']) == 7.5:
        return '2018-04-30';

    elif float(row['CURRENT_VERSION']) < 7.5:
        return 'EOL';

    else:
        return 'N/A';
        
def EOL_JBOSS(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['MAJOR_VERSION']) >= 7 :
        return '2023/02/28';
   
    elif float(row['MAJOR_VERSION']) < 7 :
        return '2019/03/31';
    
    elif float(row['MAJOR_VERSION']) < 5 :
        return 'EOL';

    else:
        return 'N/A';


def EOL_WAS(row):
    """A util to parse operatingSystem name and return the version """
    if str(row['CURRENT_VERSION']) == 8.5 :
        return 'TBD';

    elif str(row['CURRENT_VERSION']) < 8.5 and float(row['CURRENT_VERSION']) >= 7.0:
        return '2018-04-30';

    elif str(row['CURRENT_VERSION']) < 7.0:
        return 'EOL';

    else:
        return 'N/A';

def EOL_DB2(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) >= 10.5 :
        return 'TBD'

    elif (float(row['CURRENT_VERSION']) == 9.7) or (float(row['CURRENT_VERSION']) == 10.1):
         return 'EOL';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) < 9.7:
        return 'EOL';

    else:
        return 'N/A'


def EOL_AIX(row):
    """A util to parse operatingSystem name and return the version """
    if(str(row['CURRENT_VERSION'])):
        if str(row['CURRENT_VERSION']) == "None" :
            return 'N/A'
        elif float(row['CURRENT_VERSION']) == 7.2 :
            return 'TBD'

        elif float(row['CURRENT_VERSION']) == 7.1:
             return 'TBD';

        elif float(row['CURRENT_VERSION']) == 0.0:
            return 'N/A';

        elif float(row['CURRENT_VERSION']) < 7.0 and float(row['CURRENT_VERSION']) > 6.0:
            return '2018-04-30';

        elif float(row['CURRENT_VERSION']) < 6.0:
            return 'EOL';
        else:
            return 'N/A'
    else:
        return 'N/A'

def EOL_REDHAT(row):
    """A util to parse operatingSystem name and return the version """

    if str(row['CURRENT_VERSION']) == "None" :
        return 'N/A'
    elif float(row['CURRENT_VERSION']) >= 7.0 :
        return '2023-12-31'

    elif float(row['CURRENT_VERSION']) >= 6.7 and float(row['CURRENT_VERSION']) < 7.0:
        return '2020-05-31';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) >= 5.0 and float(row['CURRENT_VERSION']) < 6.7:
        return 'EOL';

    elif float(row['CURRENT_VERSION']) < 5.0:
        return 'EOL';

    else:
        return 'N/A';

def EOL_WINDOWS(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 2016 :
        return '2026-07-11'

    elif float(row['CURRENT_VERSION']) == 2018:
       return '2023-08-31';

    elif float(row['CURRENT_VERSION']) == 2012.0:
        return '2023-04-10';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) <= 2008.0 :
        return '2019-08-31';

    else:
        return 'N/A';

def EOL_SQL(row):
    """A util to parse operatingSystem name and return the version """
    if float(row['CURRENT_VERSION']) == 2014 or float(row['CURRENT_VERSION']) == 2016 :
        return 'TBD'

    elif float(row['CURRENT_VERSION']) == 2012:
        return '2021-11-30';

    elif float(row['CURRENT_VERSION']) == 0.0:
        return 'N/A';

    elif float(row['CURRENT_VERSION']) <= 2008 :
        return '2018-12-31';

    else:
        return 'N/A';

def EOL_ORACLE(row):
    """A util to parse operatingSystem name and return the version """
    if row['CURRENT_VERSION'] == "12c" :
        return 'TBD'

    elif row['CURRENT_VERSION'] == "11g":
        return '2018-09-30';

    elif row['CURRENT_VERSION'] == "10g":
            return 'EOL';
    else:
        return 'N/A';

def EOL_SOLARIS(row):
    if float(row['CURRENT_VERSION']) == 11:
            return '2019-09-30'
    elif float(row['CURRENT_VERSION']) == 10:
            return '2018-09-30';
    else:
            return 'N/A'


### Common function ###
def parse_windows(row):
    return str(row['FULL_VERSION']).split('Server')[1].split(' ')[1]

def parse_redhat(row):
    print row
    if str(row['FULL_VERSION']) == "Linux SuSe 11" or str(row['FULL_VERSION']) == "Linux SuSE 11":
        return 11
    elif str(row['FULL_VERSION']) == "Linux Oracle Enterprise Linux Server release 7.1":
        return 7.1
    elif str(row['FULL_VERSION']) == "Linux Oracle Enterprise Linux Server release 7.2" or str(row['FULL_VERSION']) == "Linux Oracle Enterprise Linux Server release 7.2":
        return 7.2
    elif str(row['FULL_VERSION']) == "Linux":
        return 'None'
    else:
        return str(row['FULL_VERSION']).split(' ')[4]
        
def parse_jboss(row):
    print row
    if str(row['VERSION']) == "5" or str(row['VERSION']) == "6":
        return '6.3.3'
    elif str(row['VERSION']) == "7":
        return '7.0.8'
    elif str(row['VERSION']) == "8" or str(row['VERSION']) == "9":
        return 9
    elif str(row['VERSION']) == "Linux":
        return 'None'
    else:
        return str(row['VERSION']).split(' ')[4]



def parse_aix(row):
    if str(row['FULL_VERSION']) == "AIX":
        return 'None'
    else:
        return str(row['FULL_VERSION']).split(' ')[1];

def parse_solaris(row):
        if str(row['FULL_VERSION']) == "Oracle Solaris 10 (64-bit)":
            return '10'
        else:
            return str(row['FULL_VERSION']).split(' ')[1];

def hsp_elg(row):
    if str(row['CURRENCY']) != 'N':
        return 'Yes';
    else:
        return 'No';

def hsp_link(row):
    if str(row['CURRENCY']) != 'N':
        return 'https://hsp-prod.fg.rbc.com/welcome'
    else:
        return '';

### Helper functions ###
def add_columns(df,columns):
    """ A util for adding more columns to dataframe """
    df_extra = pd.DataFrame(columns)
    df.join(df_extra, how='outer')
    return df;

def rename(df,recolumn):
    """A util to rename dataframe  columns"""
    df.rename(columns=recolumn, inplace=True)
    return df;

def get_subet(df,columns):
    """A util to get subset of dataframe columns"""
    df = df[columns]
    return df;

# In[3]:

def EOL(x):
    return {
        'was': EOL_WAS,
        'mq': EOL_MQ,
        'jboss': EOL_JBOSS,
        'redhat': EOL_REDHAT,
        'aix': EOL_AIX,
        'windows': EOL_WINDOWS,
        'solaris': EOL_SOLARIS,
        'db2': EOL_DB2,
        'oracle': EOL_ORACLE,
        'sql': EOL_SQL,
        'businessworks':EOL_BUSINESSWORKS,
    }.get(x, 'N/A')    # 9 is default if x not found

def currency(x):
    return {
        'was': currency_WAS,
        'mq': currency_MQ,
        'redhat': currency_REDHAT,
        'aix': currency_AIX,
        'windows': currency_WINDOWS,
        'oracle': currency_ORACLE,
        'db2': currency_DB2,
        'sql': currency_SQL,
        'solaris':currency_SOLARIS,
        'businessworks':currency_BUSINESSWORKS,
        'jboss':currency_JBOSS,
    }.get(x, 'N/A')


def parse(x):
    return {
        'redhat': parse_redhat,
        'aix': parse_aix,
        'solaris': parse_solaris,
        'windows': parse_windows,
        'jboss': parse_jboss
    }.get(x, 'N/A') # 9 is default if x not found


# In[ ]:
