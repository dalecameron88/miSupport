#Get the total number of patch servers per platform
#sql = ("SELECT software_component,software_component_version,count(software_component_version) as totalNumberOfServersOnPatch,version FROM mw_instance WHERE install_type='MQ SERVER' and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  or install_type IS NULL and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)','HP/UX') GROUP BY software_component_version,software_component,version")
sql = ("SELECT software_component,software_component_version,count(software_component_version) as totalNumberOfServersOnPatch,version FROM mw_instance WHERE  install_type='MQ SERVER' and status NOT IN ('Decommissioned') GROUP BY software_component_version,software_component,version")
patchData = pd.read_sql_query(sql,cnxn)


#Get the total number of major servers per platform
#majorsqldata = ("SELECT software_component,version,count(version) as numberOfServersOnMajorVersion,install_type,status FROM mw_instance WHERE install_type='MQ SERVER' and status NOT IN ('Decommissioned') and software_component='MQ' and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  or install_type IS NULL and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  GROUP BY version,software_component,install_type,status")
majorsqldata = ("SELECT software_component,version,count(version) as numberOfServersOnMajorVersion,install_type,status FROM mw_instance WHERE status NOT IN ('Decommissioned') and install_type='MQ SERVER' GROUP BY version,software_component,install_type,status")
majordata = pd.read_sql_query(majorsqldata,cnxn)


#Get the total number of total number of servers per platform
totalplatform = ("SELECT software_component as software_component, count(software_component) as totalservers FROM mw_instance  WHERE status NOT IN ('Decommissioned') OR install_type='MQ SERVER' and status NOT IN ('Decommissioned') GROUP BY software_component")
totalplatform = pd.read_sql_query(totalplatform,cnxn)

newdata = patchData.merge(majordata,on=['version','software_component'])

newdata = totalplatform.merge(newdata,on='software_component') ##Merge on the software component ex. MQ, DB2


#For each row determine the percentages
newdata['patch_ver_percentage'] = newdata.apply(lambda row: str(round(int(row['totalNumberOfServersOnPatch'])/float(row['numberOfServersOnMajorVersion'])*100,1)) if row['numberOfServersOnMajorVersion'] !=0 else 0.0,axis=1)
newdata['major_ver_percentage'] = newdata.apply(lambda row: str(round(int(row['totalNumberOfServersOnPatch'])/float(row['totalservers'])*100,1)) if row['numberOfServersOnMajorVersion'] !=0 else 0.0,axis=1)

