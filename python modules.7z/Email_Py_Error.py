import os
import sys
import traceback
import re
import smtplib
import getpass

def ExceptHook(etype, value, tb):
    """Formats traceback and exception data and emails the error to me: &^&^@&^&^&.com.

    Arguments:
    etype -- Exception class type
    value -- Exception string value
    tb -- Traceback string data
    """

    excType = re.sub('(<(type|class \')|\'exceptions.|\'>|__main__.)', '', str(etype)).strip()
    Email = {'TO':"Dale.Cameron@rbc.com", 'FROM':"Dale.Cameron@rbc.com", 'SUBJECT':'**  Exception **', 'BODY':'%s: %s\n\n' % (excType, etype.__doc__)}

    for line in traceback.extract_tb(tb):
        Email['BODY'] += '\tFile: "%s"\n\t\t%s %s: %s\n' % (line[0], line[2], line[1], line[3])
    while 1:
        if not tb.tb_next: break
        tb = tb.tb_next
    stack = []
    f = tb.tb_frame
    while f:
        stack.append(f)
        f = f.f_back
    stack.reverse()
    Email['BODY'] += '\nLocals by frame, innermost last:'
    for frame in stack:
        Email['BODY'] += '\nFrame %s in %s at line %s' % (frame.f_code.co_name, frame.f_code.co_filename, frame.f_lineno)
        for key, val in frame.f_locals.items():
            Email['BODY'] += '\n\t%20s = ' % key
            try:
                Email['BODY'] += str(val)
            except:
                Email['BODY'] += '<ERROR WHILE PRINTING VALUE>'
    thisHost = socket.gethostname()
    thisIP = socket.gethostbyname(thisHost)
    gmTime = time.gmtime()
    logName = 'SomeTool_v%s_%s_%s_%s.%s.%s_%s.%s.%s.log' % (__version__, thisHost, thisIP, gmTime.tm_mon, gmTime.tm_mday, gmTime.tm_year, gmTime.tm_hour, gmTime.tm_min, gmTime.tm_sec)
    if not os.path.exists(LOGS_DIR):
        try:
            os.mkdir(LOGS_DIR)
        except:
            baseLogDir = os.path.join(NET_DIR, "logs")
            if not os.path.exists(baseLogDir):
                try:
                    os.mkdir(baseLogDir)
                except:
                    pass
                else:
                    open(os.path.join(baseLogDir, logName), 'w').write(Email['BODY'])
        else:
            open(os.path.join(LOGS_DIR, logName), 'w').write(Email['BODY'])
    Email['ALL'] = 'From: %s\nTo: %s\nSubject: %s\n\n%s' % (Email['FROM'], Email['TO'], Email['SUBJECT'], Email['BODY'])
    server = smtplib.SMTP(MY_SMTP)
    server.sendmail(Email['FROM'], Email['TO'], Email['ALL'])
    server.quit()

if __name__ == '__main__':
    sys.excepthook = ExceptHook
    try:
        1 / 0
    except:
        sys.exit()