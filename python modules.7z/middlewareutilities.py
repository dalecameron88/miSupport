import ldap

def authenticate(address, username, password):
        conn = ldap.initialize('ldap://' + address)
        conn.protocol_version = 3
        conn.set_option(ldap.OPT_REFERRALS, 0)
        try:
            result = conn.simple_bind_s(username, password)


            basedn = "DC=fg,DC=rbc,DC=com" #Search these domain controllers
            name_without_domain = username[username.index("\\") + 1:]
            filter = "(&(samaccountname=" + name_without_domain + "))" ##Search by username
            results = conn.search_s(basedn,ldap.SCOPE_SUBTREE,filter)
            if not results:
                print "No Results Found"
            for dn,entry in results:
                name = str(entry['cn']) #Store the name of the user in a variable
        except ldap.INVALID_CREDENTIALS:
            print "Invalid credentials"
            return 0
        except ldap.SERVER_DOWN:
            print "Server down"
            return 0
        except ldap.LDAPError, e:
            if type(e.message) == dict and e.message.has_key('desc'):
                print "Other LDAP error: " + e.message['desc']
                return 0
            else:
                print "Other LDAP error: " + e
                return 0
        finally:
            conn.unbind_s()
        print "Succesfully authenticated"
        name = name.replace("['","") ##Remove formatting
        name = name.replace("']","")
        print name
        return name
