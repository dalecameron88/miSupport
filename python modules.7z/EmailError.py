import os
import sys
import traceback
import re
import smtplib
import psutil


def send_message(self, subject, body):
  server = smtplib.SMTP('labmailer.devfg.rbc.com', 25)

#Send the mail
msg = "Hello!" # The /n separates the message from the headers


SUBJECT = "Hello!"

TEXT = "This message was sent with Python's smtplib."

message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)

server.sendmail("autointake@sterbc.com", ["autointake@sterbc.com"], message)
server.quit()

for pid in psutil.pids():
	p = psutil.Process(pid)
	if p.name() == "httpd.exe":
		print("Apache is running")


import logging
logging.basicConfig(filename='example.log',level=logging.DEBUG)
logging.debug('This message should go to the log file')
logging.info('So should this')
logging.warning('And this, too')