
# coding: utf-8

# In[7]:

import MyopsFinal as op #Import MyOps module, used to get server information for AIX
import utilites as util
import pandas as pd
import numpy as np
from datetime import timedelta, datetime


# In[2]:


"""The shipp method is used to create a backup of what is currently in the portal and import the new data. This is created so that if there is something
wrong with the upload you can easily restore from a backup by obtaining the platforms information from the "temp" collection"""


def shipp(aixFinal):
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_aix_temp'].drop()
    util.insert_mongo(master, 'master_aix_temp') #Create the backup of the older data

    db['master_view'].delete_many({'PLATFORM_NAME':'AIX'}) #Delete  AIX in the master inventory table
    util.insert_mongo(aixFinal, 'master_view') #Import the new data into the master inventory table


# In[3]:

def aix_final():
    oldAIX = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME':'AIX'})
    oldAIX = oldAIX[['SERVER_NAME','DATE','COMMENTS', 'STRATEGY']] ##This line is used to reserve the user input: date, comments, and strategy from the old data as well as the server name.

    op.aix_final(op.data) #Obtains AIX data from myOps the datac calling the aix_final method from the myOps module

    aix = util.read_mongo('dev','aix_views') #Reading the aix_views NOTE: AIX views is populated via the aix_final method

    tmp= oldAIX.merge(aix, on=['SERVER_NAME'], how='left', indicator=True) #This does a left merge to the old data, to check which servers were on the portal before but not anymore. They might not be there due to decomission
    mergerMissing = tmp[tmp['_merge'] == 'left_only']
    mergerMissing.to_csv('C:\py-scripts\main\invs\servers\info\\aix_missing_servers.csv',index=False) ##Extract to csv
    mergerMissing[mergerMissing['DATE'] != ''].to_csv('C:\py-scripts\main\invs\servers\info\\aix_missing_dates.csv',index=False)

    aixFinal = aix.merge(oldAIX, on=['SERVER_NAME'], how='left') #Merge the new data with the old data via a left join so that you can preserve the user input based on SERVER_NAME
    aixFinal = aixFinal.replace(np.nan, '', regex=True) #Replace NAN's created with '' due to datatable crashing if NaN's are in the record set 
    aixFinal = aixFinal.drop_duplicates('SERVER_NAME') #Drop any duplicate enteries that may have occured
    shipp(aixFinal) #Pass the data for insertion into mongo db

if __name__ == '__main__':
    aix_final()
