import requests, sys, json
from requests import session

payload = {
    'username': '',
    'password': 'pt00@admin'
}

with session() as c:
    c.post('http://pt00.devfg.rbc.com/signin.php', data=payload)
    response_ = c.get('http://pt00.devfg.rbc.com/mdwAPI.php')
    #print(response.headers)
    #print(response.text)
response = json.load(response_)
print response





























#--------------------------------------------------------------------------------------------------
from requests.auth import HTTPBasicAuth
response = requests.get('http://pt00.devfg.rbc.com/mdwAPI.php', auth=HTTPBasicAuth('','pt00@admin'))
#print response.json()
struct = {}
try: #try parsing to dict
    dataform = str(response).strip("'<>() ").replace('\'', '\"')
    struct = json.loads(dataform)
except:
    print repr(struct)
    print sys.exc_info()