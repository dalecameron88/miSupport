import numpy as np
from itertools import chain

df=[]
df['exonStart'] = df['exonStart'].str.split(',')
df['exonEnds'] = df['exonEnds'].str.split(',')

lens = list(map(len, df['exonStart']))

res = pd.DataFrame({'chrom': np.repeat(df['chrom'], lens),
                    'exonStart': list(chain.from_iterable(df['exonStart'])),
                    'exonEnds': list(chain.from_iterable(df['exonEnds'])),
                    'name': np.repeat(df['name'], lens)})

print(res)


#res = pd.DataFrame({'chrom': np.repeat(df['chrom'], lens), 'exonStart': list(chain.from_iterable(df['exonStart'])), 'exonEnds': list(chain.from_iterable(df['exonEnds'])), 'name': np.repeat(df['name'], lens)})


#chrom   exonStart     exonEnds      name
#chr1    100,200,300   110,210,310   gen1
#chr1    500,700       600,800       gen2
#chr2    50,60,70,80   55,65,75,85   gen3

res = pd.DataFrame({'chrom': np.repeat(df['chrom'], lens),'exonStart': list(chain.from_iterable(df['exonStart'])), 'exonEnds': list(chain.from_iterable(df['exonEnds'])), 'name': np.repeat(df['name'], lens)})

#-----------------------------------------------
df=[]
df['APP_CODE'] = df['APP_CODE'].str.split(',')
df['APP_CODE'] = df['APP_CODE'].str.split(',')

lens = list(map(len, df['APP_CODE']))


res = pd.DataFrame({'SERVER_NAME': np.repeat(df['SERVER_NAME'], lens),
                    'APP_CODE': list(chain.from_iterable(df['APP_CODE'])),
                    'CURRENT_VERSION': list(chain.from_iterable(df['CURRENT_VERSION'])),
                    'PLATFORM': np.repeat(df['PLATFORM'], lens)})

print(res)

