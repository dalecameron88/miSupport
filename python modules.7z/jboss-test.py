
# coding: utf-8

# In[61]:

import utilites as util
import pandas as pd
import pyodbc
from pymongo import MongoClient
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json
from pandas.io.json import json_normalize
from datetime import timedelta, datetime

#Renamed columns, these columns are used to rename columns that are different in the excel spreadsheet and it is done so that it can match the mongoDB fields
data = pd.DataFrame()
cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )
renamed_columns={
                    'APP CODE': 'APP_CODE',
                    'Strategy':'STRATEGY' ,
                    'SERVER NAME': 'SERVER_NAME',
                    'Date': 'MIGRATION_DATE',
                    'Status':'STATUS',
                    'Comments':'COMMENT',
                    'ENV':'ENVIRONMENT',
                    'App Name':'APP_NAME',
                    'L3 Org':'L3_ORG',
                    'App Custodian':'APP_CUSTODIAN',
                    'Major Ver':'MAJOR_VERSION',
                    'Target Ver':'TARGET_VERSION', 
                    'Cr #': 'CR_NUMBER',
                    'Platform_tpye': 'PLATFORM_TYPE',
                        }
columns = ['APP_CODE', 'SERVER_NAME', 'ENVIRONMENT', 'VERSION', 'END_OF_SUPPORT', 'MAJOR_VERSION', 'OUTSIDE_IP', 'ADMIN_IP']

def server():
	columns = [ 'APP_CODE', 'SERVER_NAME', 'PLATFORM_NAME' ,'MIGRATION_ELIGIBILITY','COMPLIANCE','END_SUPPORT', 'CURRENT_VERSION', 'ENVIRONMENT', 'APP_NAME', 'L3_ORG', 'L3', 'L4', 'L5', 'TYPE', 'SOURCE', 'DB_COUNT', 'DATE', 'APP_CUSTODIAN', 'COMMENTS', 'STRATEGY', 'INSTANCE_NM', 'SERVICE_WINDOW_CYCLE', 'VIRP_DATE', 'VIRP', '_id', 'TSS_PERCENTAGE', 'TSS_PASS_FAIL', 'TSS_LINK_REPORT']
	index_column = "server_name"
	collection = "master_view"
	results = dt.DataTablesServer(request, columns, index_column, collection).output_result()

	# return the results as a string for the datatable
	return json.dumps(results)

#Read the csv file and prepare the data
def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,software_component_version as VERSION, version as MAJOR_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_OF_SUPPORT, admin_ip as ADMIN_IP, outside_IP as OUTSIDE_IP from mw_instance ")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('JBOSSDATAFRMMDW123.csv',encoding='utf-8')
    return data;

#Read the file and then for each record in the file create a dataframe column
def prep_initial():
    data = read_file()
    data = l.rename(data, renamed_columns)
    data = l.get_subet(data, columns)
    data['CURRENCY'] = data.apply(l.currency('jboss'),axis=1) #Used to create the currency column - determine the currency based on the current versiion
    data['END_OF_SUPPORT'] = data.apply(l.EOL('jboss'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['HSP_LINK'] = data.apply(l.hsp_link,axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.strip()
    data = data.replace(np.nan, '', regex=True)
    data['PLATFORM_NAME'] = 'jboss'
    data['TYPE'] = 'N/A' #Since these columns don't apply to MQ they are set as N/A
    data['SOURCE'] = 'N/A'
    data['DB_COUNT'] = 'N/A'
    data['INSTANCE_NM'] = 'N/A'
    print len(data);
    del data['APP_CODE']
    del data['ENVIRONMENT']
    del data['MAJOR_VERSION']
    data['SERVER_NAME'] = data['SERVER_NAME'].str.replace(' ', '') #Remove the spacing when reading from excel spreadsheet
    data['SERVER_NAME']  =  data['SERVER_NAME'].str.lower()
    data['VERSION']  =  data['VERSION'].str[3:7] # print(ss[7:])Convert the current version to string if it is not the datatable library will be unable to search it
    return data;

def update_usrinput():
	try:
		data = read_file()
		print "THIS IS THE OUTPUT FROM DATAFRAME"
		print data
		l.update_usrinput(data,'master_view', key='server_name')
	except:

	        return data;

#Get the OS's MQ is installed on
def get_servers(servers=["WINDOWS",'REDHAT', 'iSeries', 'AIX' ]):
    data = util.read_mongo('dev', 'master_view', query={ "PLATFORM_NAME": { "$in": servers } })
    data = data[['APP_CODE', 'SERVER_NAME', 'ENVIRONMENT']]
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    return data;

#Obtain the old data
def curr_platform(platform='JBoss'):
    data = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['DATE','SERVER_NAME','COMMENTS','STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']]  #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    return data;

 #Merge with IIPM to get the server details ex.APP NAME, L3, L4, L5, if it is not found in IIPM drop the server
#def merge_iipm(data, iipm):
#    data['APP_CODE'] = data['APP_CODE'].str.upper()
#    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
#    data = pd.merge(data, iipm, on='APP_CODE', how='left')
#    data[data['APP_CODE'].isnull()].to_csv('jboss_missing_servers.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
#    data = data[data['APP_CODE'].notnull()]
#    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
#    print len(data)
#    return data;

#Check for missing dates
def check_dates(data,oldJBOSS):
    print "dates on new portal"
    l.update_usrinput(data,'master_view', key='SERVER_NAME')
    print len(data[data['DATE'].notnull()])
    dateMiss = oldJBOSS[oldJBOSS['DATE'].notnull()].merge(data[data['DATE'].notnull()],indicator=True,on="SERVER_NAME",how='left')[['SERVER_NAME','APP_CODE','_merge']]
    dateMiss = dateMiss[dateMiss['_merge'] == 'left_only']
    dateMiss.to_csv('jboss_date_missing.csv', index=False, columns=['APP_CODE','SERVER_NAME'])
    print "dates on pervious dataset:"
    print len(oldJBOSS[oldJBOSS['DATE'].notnull()])

def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    data.drop_duplicates('SERVER_NAME', inplace=True)
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_mq_temp'].drop()
    util.insert_mongo(master, 'master_mq_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'jboss'})
    util.insert_mongo(data, 'master_view')


def prep_final():
    iipm = util.read_mongo('dev','iipm') #Read IIPM for the correct data
    data = prep_initial(); #Prepare the data for processing
    servers = get_servers(servers=["WINDOWS",'REDHAT', 'AIX', 'iSeries']); #Obtain the OS's MQ is installed on
    data = pd.merge(data, servers, on='SERVER_NAME', how='left') #Merge the data to check for matches
    print "size of file after mergin with servers(to get correct app code and env):"
    #data = merge_iipm(data, iipm);
    data.drop_duplicates('SERVER_NAME', inplace=True)
    print len(data)
    oldJBOSS = curr_platform()
    data = data.merge(oldJBOSS, on='SERVER_NAME', how='left')   #Merge the new data with the old data in order to preserve the comments, date, strategy, and comments
    check_dates(data, oldJBOSS);
    #shipp(data); #Send the data to be inserted into mongo db
    return data;

if __name__ == '__main__':
    data = prep_final()
data.to_csv('TESTJBOSS123.csv',encoding='utf-8',index=None)