
# coding: utf-8

# In[7]:

import MyOpsFinal as op #Import MyOps module, used to get server information for AIX
import utilites as util
import pandas as pd
import numpy as np
from datetime import timedelta, datetime


# In[2]:


"""The shipp method is used to create a backup of what is currently in the portal and import the new data. This is created so that if there is something
wrong with the upload you can easily restore from a backup by obtaining the platforms information from the "temp" collection"""


def shipp(aixFinal):
    master = util.read_mongo('kri','master_view')
    db = util._connect_mongo()
    db['master_aix_temp'].drop()
    util.insert_mongo(master, 'master_aix_temp') #Create the backup of the older data

    db['master_view'].delete_many({'PLATFORM_NAME':'AIX'}) #Delete  AIX in the master inventory table
    util.insert_mongo(aixFinal, 'master_view') #Import the new data into the master inventory table


# In[3]:

def aix_final():
    oldAIX = util.read_mongo('kri', 'master_view', query={'PLATFORM_NAME':'AIX'})
    oldAixDetails = oldAIX
    oldAIX = oldAIX[['SERVER_NAME','DATE','COMMENTS', 'STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] ##This line is used to reserve the user input: date, comments, and strategy from the old data as well as the server name.

    op.aix_final(op.data) #Obtains AIX data from myOps the datac calling the aix_final method from the myOps module

    aix = util.read_mongo('kri','aix_views') #Reading the aix_views NOTE: AIX views is populated via the aix_final method

    tmp= oldAIX.merge(aix, on=['SERVER_NAME'], how='left', indicator=True) #This does a left merge to the old data, to check which servers were on the portal before but not anymore. They might not be there due to decomission
    serversMissing = tmp[tmp['_merge'] == 'left_only']
    serversMissing = serversMissing[['SERVER_NAME']]

    serversMissing = serversMissing.merge(oldAixDetails, on='SERVER_NAME') #Used to get the details of the missing servers details
    serversMissing['DAYS_OFFLINE'] = serversMissing['DAYS_OFFLINE'] = 1

    existingMissingServers = pd.read_csv('C:\py-scripts\main\invs\servers\info\\aix_missing_servers.csv')
    existingMissingServers['SERVER_NAME'] = existingMissingServers['SERVER_NAME'].str.strip()
    aix['SERVER_NAME'] = aix['SERVER_NAME'].str.strip()

    for index,row in existingMissingServers.iterrows():
            if  existingMissingServers.loc[index,'SERVER_NAME'] in aix.SERVER_NAME.values:
                print 'ITS HERE'
                existingMissingServers.drop(index,inplace=True) #server is back online
            elif existingMissingServers.loc[index,'SERVER_NAME'] not in aix:
                existingMissingServers.loc[index,'DAYS_OFFLINE'] = existingMissingServers.loc[index,'DAYS_OFFLINE'] + 1

    ninedays = existingMissingServers[(existingMissingServers['DAYS_OFFLINE'] == 9)]
    print 'equal to 9'
    print 9

    for index,row in serversMissing.iterrows():
            if serversMissing.loc[index,'SERVER_NAME'] in ninedays.SERVER_NAME.values:
               serversMissing.drop(index,inplace=True) #remove the server to prevent it from resetting the count and staying on the portal

    print serversMissing

    lessthan8 = existingMissingServers[(existingMissingServers['DAYS_OFFLINE'] > 0) & (existingMissingServers['DAYS_OFFLINE'] < 9)]

    missingServers = pd.concat([serversMissing,lessthan8], axis=0,ignore_index=True)
    missingServers = missingServers.drop_duplicates(subset='SERVER_NAME',keep='last')

    missingServers.to_csv('C:\py-scripts\main\invs\servers\info\\aix_missing_servers.csv', index=False)
    missingServers.to_csv('C:\py-scripts\main\invs\servers\info\\aix_missing_backup'+ datetime.now().strftime('%Y-%m-%d') + '.csv')


    merger = aix.merge(oldAIX, on=['SERVER_NAME'], how='left') #Merge the new data with the old data via a left join so that you can preserve the user input based on SERVER_NAME
    aixFinal = pd.concat([missingServers,merger], axis=0,ignore_index=True)

    aixFinal = aixFinal.replace(np.nan, '', regex=True) #Replace NAN's created with '' due to datatable crashing if NaN's are in the record set
    aixFinal = aixFinal.drop_duplicates('SERVER_NAME') #Drop any duplicate enteries that may have occured
    aixFinal.loc[aixFinal['CURRENT_VERSION'] == 'None', 'COMPLIANCE'] = 'Approaching Non Compliant (EOL within 18mths)' #Used to fix missing versions
    shipp(aixFinal) #Pass the data for insertion into mongo db

if __name__ == '__main__':
    aix_final()
