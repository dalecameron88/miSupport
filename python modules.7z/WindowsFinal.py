# coding: utf-8

# In[2]:

import MyopsFinal as op
import utilites as util
import pandas as pd
import numpy as np
from datetime import timedelta, datetime


# In[3]:

import pyodbc
import pandas.io.sql as psql
import pandas as pd
import json
import pymongo
import numpy as np
import logic as l
import re
from datetime import timedelta, datetime


def print_info(windowsOPS,windowsDSL,windows):
    print 'Windows Concat: ' +  str(len(windows));
    print 'MyOPS: ' + str(len(windowsOPS));
    print 'DSL: ' +  str(len(windowsDSL));
    print 'Windows size after Date Check: ' +  str(len(windows));

def windows_merge():
    windowsDSL = util.read_mongo('dev','dsl_windows')
    windowsOPS =  util.read_mongo('dev','myops_windows')
    windowsOPS['SERVER_NAME'] = windowsOPS['SERVER_NAME'].str.lower()
    windowsDSL['SERVER_NAME'] = windowsDSL['SERVER_NAME'].str.lower()
    del windowsOPS['LAST_UPDATE']
    del windowsDSL['LAST_UPDATE']
    windowsOPS['SOURCE'] = 'MyOps'
    windowsDSL['SOURCE'] = 'DSL'
    windows = pd.concat([windowsDSL,windowsOPS])
    windows = windows.drop_duplicates('SERVER_NAME').reset_index(drop=True)
    windows['SERVER_NAME'] = windows['SERVER_NAME'].str.lower()
    windows = windows.replace(np.nan, '', regex=True)
    print_info(windowsOPS,windowsDSL,windows)
    windows['PLATFORM_NAME'] = 'WINDOWS';
    windows['SOURCE'] = 'N/A'
    windows['DB_COUNT'] = 'N/A'
    return windows;

def merge_iipm(windows):
    windows = windows.replace(np.nan, '', regex=True)
    windows['APP_CODE'] = windows['APP_CODE'].str.upper()
    iipm = util.read_mongo('dev', 'iipm')
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    print 'windows before app code:'
    print len(windows)
    windows = windows.merge(iipm, on='APP_CODE')
    print 'windows after app code:'
    print len(windows)
    return windows;

def shipp(windowsFinal):
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_windows_temp'].drop()
    util.insert_mongo(master, 'master_windows_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'WINDOWS'})
    util.insert_mongo(windowsFinal, 'master_view')

def windows_final():
    windows = windows_merge()
    windows = merge_iipm(windows)
    oldWindows = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME':'WINDOWS'})
    oldWindowsDetails = oldWindows
    oldWindows = oldWindows[['SERVER_NAME','DATE','COMMENTS','STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']]
    oldWindows['SERVER_NAME'] = oldWindows['SERVER_NAME'].str.lower()
    oldWindows = oldWindows.replace(np.nan, '', regex=True)
    merger = oldWindows.merge(windows, on=['SERVER_NAME'], indicator=True,  how='left')
    serversMissing = merger[merger['_merge'] == 'left_only']
    serversMissing = serversMissing[['SERVER_NAME']]

    serversMissing = serversMissing.merge(oldWindowsDetails, on='SERVER_NAME') #Used to get the details of the missing servers details
    serversMissing['DAYS_OFFLINE'] = serversMissing['DAYS_OFFLINE'] = 1

    existingMissingServers = pd.read_csv('windows_missing_servers.csv')
    existingMissingServers['SERVER_NAME'] = existingMissingServers['SERVER_NAME'].str.strip()
    windows['SERVER_NAME'] = windows['SERVER_NAME'].str.strip()
    existingMissingServers[["L3_ENUM", "L4_ENUM", "L5_ENUM", "APP_CUSTODIAN", "CURRENT_VERSION"]] = existingMissingServers[["L3_ENUM", "L4_ENUM", "L5_ENUM", "APP_CUSTODIAN", "CURRENT_VERSION"]].astype(str)

    for index,row in existingMissingServers.iterrows():
        if  existingMissingServers.loc[index,'SERVER_NAME'] in windows.SERVER_NAME.values:
            print 'ITS HERE'
            existingMissingServers.drop(index,inplace=True) #server is back online
        elif existingMissingServers.loc[index,'SERVER_NAME'] not in windows:
            existingMissingServers.loc[index,'DAYS_OFFLINE'] = existingMissingServers.loc[index,'DAYS_OFFLINE'] + 1

    ninedays = existingMissingServers[(existingMissingServers['DAYS_OFFLINE'] == 9)]
    print 'equal to 9'
    print 9

    for index,row in serversMissing.iterrows():
        if serversMissing.loc[index,'SERVER_NAME'] in ninedays.SERVER_NAME.values:
           serversMissing.drop(index,inplace=True) #remove the server to prevent it from resetting the count and staying on the portal

    print serversMissing

    lessthan9 = existingMissingServers[(existingMissingServers['DAYS_OFFLINE'] > 0) & (existingMissingServers['DAYS_OFFLINE'] < 9)]

    missingServers = pd.concat([serversMissing,lessthan9], axis=0,ignore_index=True)
    missingServers = missingServers.drop_duplicates(subset='SERVER_NAME',keep='last')

    missingServers.to_csv('windows_missing_servers.csv', index=False)
    #missingServers.to_csv('C:\py-scripts\main\invs\servers\info\windows_missing_backup'+ datetime.now().strftime('%Y-%m-%d') + '.csv')


    merger = windows.merge(oldWindows, on=['SERVER_NAME'],indicator=True,how='left')



    windowsFinal = pd.concat([missingServers,merger], axis=0,ignore_index=True)
    windowsFinal = windowsFinal.replace(np.nan, '', regex=True)
    windowsFinal.loc[windowsFinal['CURRENT_VERSION'] == 'nan', 'COMPLIANCE'] = 'Approaching Non Compliant (EOL within 18mths)' #Used to fix missing versions
    shipp(windowsFinal)
    windowsFinal.to_csv('windowsFinalWithCompliance.csv',encoding='utf-8')


if __name__ == '__main__':
    data = windows_final();