import json
from bs4 import BeautifulSoup
import urllib3.request
url = "http://pt00.devfg.rbc.com/mdwAPI.php"

http = urllib3.PoolManager()

headers = urllib3.util.make_headers(basic_auth='pt00@admin')
response = http.request('GET', url, headers)
soup = BeautifulSoup(response.data)
print soup

#x = urllib3.request(url)
#raw_data = x.read()
#encoding = x.info().get_content_charset('utf8')  # JSON default
#print(raw_data)   #this is data in string format
#data = json.loads(raw_data.decode(encoding))
#print(data)   #this would be your json data
#urllib3.exceptions.MaxRetryError: HTTPConnectionPool port=80): Max retries exceeded with url: