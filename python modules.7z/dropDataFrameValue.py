df[df['A'].isin([3, 6])]


import pandas as pd

a = ['2015-01-01' , '2015-02-01']

df = pd.DataFrame(data={'date':['2015-01-01' , '2015-02-01', '2015-03-01' , '2015-04-01', '2015-05-01' , '2015-06-01']})

print(df)
#         date
#0  2015-01-01
#1  2015-02-01
#2  2015-03-01
#3  2015-04-01
#4  2015-05-01
#5  2015-06-01

df = df[~df['date'].isin(a)]

print(df)
#         date
#2  2015-03-01
#3  2015-04-01
#4  2015-05-01
#5  2015-06-01




df[ ~(df['ColY'].str.contains("Y") & df['ColX'].str.contains("F")) ]


data[ ~(data['APP_CODE'].str.contains("WAJ0") & df['SERVER_NAME'].str.contains("usvbwengd10")) ]