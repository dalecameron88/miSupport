import requests
import urllib2, base64
import pandas as pd
import utilites as util
import pandas as pd
from pymongo import MongoClient
import pyodbc
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json


#Read the csv file and prepare the data
'''def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_SUPPORT from mw_instance WHERE software_component='DB2' AND STATUS = 'Active' AND product_name IN ('DB2', ' ')")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('WASAPIDATAFRMMDW123.csv',encoding='utf-8')
    return data; '''

	
'''def getWasApiData():
    request = urllib2.Request("http://pt00.devfg.rbc.com/mdwAPI.php")
    base64string = base64.b64encode('%s' % ('pt00@admin'))
    request.add_header('Content-Type', 'application/json')
    request.add_header('Cookie', 'PHPSESSID=g60444lggvc1oiaubii2de5454')
    #request.add_header("Authorization", "Basic %s" % base64string)
    result = urllib2.urlopen(request)
    data = json.load(result)
    print 'This is from the WAS API'
    print data
    keys = []
    vals = []
    for d in data:
        val = []
        for k,v in d.items():
            keys.append(k)
            val.append(v)
        vals.append(val)
	wasApiData = pd.DataFrame([v for v in vals], columns=list(dict.fromkeys(keys)))
	wasApiData.to_csv('WAS_PATCH_INFOAug212018.csv', encoding='utf-8', index=False)
	print wasApiData'''

def getWasApiData():
    request = urllib2.Request("http://pt00.devfg.rbc.com/mdwAPI.php")
    base64string = base64.b64encode('%s' % ('pt00@admin'))
    request.add_header('Content-Type', 'application/json')
    request.add_header('Cookie', 'PHPSESSID=g60444lggvc1oiaubii2de5454')
    #request.add_header("Authorization", "Basic %s" % base64string)   
    result = urllib2.urlopen(request)
    data = json.load(result)
    keys = []
    vals = []
    for d in data:
        val = []
        for k,v in d.items():
            keys.append(k)
            val.append(v)
        vals.append(val)

    data = pd.DataFrame([v for v in vals], columns=list(dict.fromkeys(keys)))
    data.to_csv('WAS_PATCH_INFO.csv', encoding='utf-8', index=False)
    print data
    return data


#Merge with IIPM to get the server details, if it is not found in IIPM drop the server
'''def merge_mdw(data, wasApiData):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    wasApiData['APP_CODE'] = wasApiData['APP_CODE'].str.upper()
    data = pd.merge(data, wasApiData, on='APP_CODE', how='left')
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with mdw and getting rid of inccorect servers:"
    print len(data)
    data1 = getWasApiData()
    print data1
    return data;'''

	
def db2_final():
    #iipm = util.read_mongo('devuser','iipm') #Read IIPM for the correct data  
	#data = prep_data(); #Prepare the data for processing
    #servers = get_servers(servers=["WINDOWS",'REDHAT', 'AIX','Linux', 'NT', 'Unix', 'zLinux']); #Obtain the OS's DB2 is installed on
    #data = pd.merge(data, servers, on='SERVER_NAME', how='left') #Merge the data to check for matches
    #print "size of file after mergin with servers(to get correct app code and env):"
    data = getWasApiData()
    #print len(data)
    #oldDB2 = curr_platform()
    #data = data.merge(oldDB2, on='SERVER_NAME', how='left') ##Merge the new data with the old data in order to preserve the comments, date, strategy, and comments
    #data.drop_duplicates('SERVER_NAME', inplace=True)
    #check_dates(data, oldDB2); #Check to see if any dates were dropped
    #data.loc[data['CURRENT_VERSION'] == 'none', 'COMPLIANCE'] = 'Approaching Non Compliant (EOL within 18mths)' #Used to fix missing versions
    #shipp(data); #Send the data to be inserted into mongo db
    return data;
    #if __name__ == '__main__':
data = getWasApiData()
data.to_csv('TESTWASAPI.csv',encoding='utf-8',index=None)
#data.to_csv('TESTDB2-123.csv',encoding='utf-8',index=None)