import pandas as pd
import utilites as util
import numpy as np
import logic as l

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server
def merge_iipm(data,iipm):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data[data['APP_CODE'].isnull()].to_csv('C:\py-scripts\main\invs\BizWorks\BusinessWorks_servers_missing.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Obtain the old data
def curr_platform(platform='BusinessWorks'):
    data = util.read_mongo('kri', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['DATE','SERVER_NAME','COMMENTS','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    #check data > file
    #data.to_csv("output.csv", sep=',', encoding='utf-8')
    return data

def prep_data():
    data = pd.read_csv('C:\py-scripts\main\invs\BizWorks\BusinessWorks.csv')
    data['HSP_LINK'] = 'https://hsp-prod.fg.rbc.com/welcome'
    data['CURRENCY'] = data.apply(l.currency('businessworks'),axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    data['END_SUPPORT'] = data.apply(l.EOL('businessworks'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['DB_COUNT'] = ""
    data['SOURCE'] = "N/A"
    data['TYPE'] = "N/A"
    data['PLATFORM_NAME'] = "BusinessWorks"
    data['INSTANCE_NM'] = "N/A"
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].astype(str)
    return data


def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    master = util.read_mongo('kri','master_view')
    db = util._connect_mongo()
    db['master_business_works_temp'].drop()
    util.insert_mongo(master, 'master_business_works_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'BusinessWorks'})
    util.insert_mongo(data, 'master_view')


def businessworksfinal():
    #get data from iipm table
    iipm = util.read_mongo('kri', 'iipm')
    db = util._connect_mongo()
    #get data from csv file
    data = prep_data()
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data,iipm)
    print len(data)
    #get data from master_view with columnes ['DATE','SERVER_NAME','COMMENTS','STRATEGY']
    oldBusinessWorks = curr_platform()
    data = data.merge(oldBusinessWorks,on='SERVER_NAME',how='left')
    data.drop_duplicates(['SERVER_NAME','APP_CODE'],inplace=True)
    print "size of file after dropping duplicates"
    print len(data)

    #update master_business_works_temp with old master_view;
    #update master_view(BusinessWorks) with merged data
    shipp(data)
    return data;

data = businessworksfinal()