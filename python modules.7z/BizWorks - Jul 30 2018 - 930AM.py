import pandas as pd
import utilites as util
import pyodbc
import numpy as np
import logic as l

#mdw DB connection string
cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )

#Merge with IIPM to get the server details, if it is not found in IIPM drop the server # df.set_index('book').authors.str.split(',', expand=True).stack().reset_index('book')
def merge_iipm(data,iipm):
    data['APP_CODE'] = data['APP_CODE'].astype('str')
    data['APP_CODE'] = data['APP_CODE'].str.split(',', expand=True)
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data[data['APP_CODE'].isnull()].to_csv('BusinessWorks_servers_missing.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

#Obtain the old data
def curr_platform(platform='BusinessWorks'):
    data = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['APP_CODE','DATE','SERVER_NAME','COMMENTS','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    #check data > file
    #data.to_csv("output.csv", sep=',', encoding='utf-8')
    return data

def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    sql = ("SELECT grouped_app_code as APP_CODE, srvr_inty_id as srvr_inty_id, server_name as SERVER_NAME,environment as ENVIRONMENT,software_component_version as VERSION, version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_OF_SUPPORT from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active' ")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('BissnessWorksDATAFRMMDW123.csv',encoding='utf-8')
    return data;

def prep_data():
    sql1 = ("SELECT mv_app_code as APP_CODE, srvr_inty_id as srvr_inty_id, server_name as SERVER_NAME,environment as ENVIRONMENT,software_component_version as VERSION, version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_OF_SUPPORT from mw_instance WHERE software_component='BusinessWorks' AND STATUS = 'Active' ")
    data1 = pd.read_sql_query(sql1,cnxn)
    data = read_file()
    data['HSP_LINK'] = 'https://hsp-prod.fg.rbc.com/welcome'
    data['CURRENCY'] = data.apply(l.currency('businessworks'),axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.lower()
    data['END_SUPPORT'] = data.apply(l.EOL('businessworks'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['DB_COUNT'] = ""
    data['SOURCE'] = "N/A"
    data['TYPE'] = "N/A"
    data['PLATFORM_NAME'] = "BusinessWorks"
    data['INSTANCE_NM'] = "N/A"
    data['CURRENT_VERSION'] = data['CURRENT_VERSION'].astype(str)
    data['srvr_inty_id'] = data['srvr_inty_id']
    data['APP_CODE'] = data['APP_CODE'].astype(str)
    data1['APP_CODE'] = data1['APP_CODE'].astype(str)
    data['APP_CODE'].replace(np.nan, '000', regex=True)
    data1['APP_CODE'].replace(np.nan, '000', regex=True)
    #data.append(data['APP_CODE'].str.split(','))
    #data['APP_CODE'] = pd.DataFrame(data.APP_CODE.str.split(',').tolist())
    if data is not None:
        data.append(data['APP_CODE'].str.split('/'))
	data = pd.concat([pd.Series(row['SERVER_NAME'], row['APP_CODE'].split(',')) for _, row in data.iterrows()]).reset_index()
       #data2.columns = ['APP_CODE', 'SERVER_NAME']
	#b = DataFrame(a.var1.str.split(',').tolist(), index=a.var2).stack()
	#data.append(data2)
	data.columns = ['APP_CODE', 'SERVER_NAME'] # renaming var1
    print 'This is the Grouped AppCode Output'
    #print output -     windows = windows.merge(iipm, on='APP_CODE')
    data['APP_CODE'] = data['APP_CODE'].str.strip()
    data['APP_CODE'] = data['APP_CODE'].str[0:4]
    data.merge(data1, on='APP_CODE')
    #data = pd.concat([data1, data])
    print data
    return data

#df2 = pd.DataFrame([[5, 6], [7, 8]], columns=list('AB'))
def shipp(data):
    data = data.replace(np.nan, '', regex=True)
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_business_works_temp'].drop()
    util.insert_mongo(master, 'master_business_works_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'BusinessWorks'})
    util.insert_mongo(data, 'master_view')


def businessworksfinal():
    #get data from iipm table
    iipm = util.read_mongo('dev', 'iipm')
    db = util._connect_mongo()
    #get data from csv file
    data = prep_data()
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(data,iipm)
    print len(data)
    #get data from master_view with columnes ['DATE','SERVER_NAME','COMMENTS','STRATEGY']
    oldBusinessWorks = curr_platform()
    data = data.merge(oldBusinessWorks,on=['SERVER_NAME','APP_CODE'],how='left')
    #data.drop_duplicates(['SERVER_NAME','APP_CODE'],inplace=True)
    #print "size of file after dropping duplicates"
    print len(data)

    #update master_business_works_temp with old master_view;
    #update master_view(BusinessWorks) with merged data
    #shipp(data)
    return data;

if __name__ == '__main__':
    data = businessworksfinal()
data.to_csv('TESTBizWorks123.csv',encoding='utf-8',index=None)