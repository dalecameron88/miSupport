# Import modules
from xml.dom import minidom
import urllib2
 
url = 'https://www.boardgamegeek.com/xmlapi2/thing?id=13&stats=1' # define XML location
dom = minidom.parse(urllib2.urlopen(url)) # parse the data

#############################
from xml.dom import minidom

doc = minidom.parse("staff.xml")

# doc.getElementsByTagName returns NodeList
name = doc.getElementsByTagName("name")[0]
print(name.firstChild.data)

staffs = doc.getElementsByTagName("staff")
for staff in staffs:
        sid = staff.getAttribute("id")
        nickname = staff.getElementsByTagName("nickname")[0]
        salary = staff.getElementsByTagName("salary")[0]
        print("id:%s, nickname:%s, salary:%s" %
              (sid, nickname.firstChild.data, salary.firstChild.data))

###########################################################

from xml.dom import minidom
import urllib2
 
url = 'https://www.boardgamegeek.com/xmlapi2/thing?id=13&stats=1' # define XML location
dom = minidom.parse(urllib2.urlopen(url)) # parse the data

owned = dom.getElementsByTagName('owned')
owned = int(owned[0].attributes['value'].value

link = dom.getElementsByTagName('link')
categories = [items.attributes['value'].value for items in link if items.attributes['type'].value == "boardgamecategory"]

categories = [items.attributes['value'].value for items in link if items.attributes['type'].value == "boardgamecategory"]
 
for items in link:
    if items.attributes['type'].value == "boardgamecategory":
        return items.attributes['value'].value