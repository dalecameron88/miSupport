import pyodbc

cnxn = pyodbc.connect( 'Driver={SQL Server};'
						'Database=mw_inventory;'
						'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
						'Port=1433'
						'uid=DLBV0SRVMW'
						'pwd=H1b^sTr0n%'
						 )

cursor = cnxn.cursor()

# platform = request.json['platform']
#cursor.execute("select * from mw_instance where server_name ='se128551' ")
cursor.execute("UPDATE mw_instance SET SERVICE_WINDOW_CYCLE = 'CYCLE THREE' WHERE SERVER_NAME= 'se128551' ")
print 'SQL EXECUTED'
try:
			cnxn.commit()
			resp = '201'
except pyodbc.Error as ex:
			sqlstate = ex.args[0] + ex.args[1]
			print(sqlstate)
			resp = '404'
cnxn.close