# coding: utf-8

# In[61]:

import utilites as util
import pandas as pd
from pymongo import MongoClient
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json
from datetime import timedelta, datetime

#Renamed columns, these columns are used to rename columns that are different in the excel spreadsheet and it is done so that it can match the mongoDB fields
renamed_columns={
                    'APP CODE': 'APP_CODE',
                    'Strategy':'STRATEGY' ,
                    'SERVER NAME': 'SERVER_NAME',
                    'Date': 'MIGRATION_DATE',
                    'Status':'STATUS',
                    'Comments':'COMMENT',
                    'ENV':'ENVIRONMENT',
                    'App Name':'APP_NAME',
                    'L3 Org':'L3_ORG',
                    'App Custodian':'APP_CUSTODIAN',
                    'Major Ver':'CURRENT_VERSION',
                    'Target Ver':'TARGET_VERSION',
                    'Cr #': 'CR_NUMBER',
                    'Platform_tpye': 'PLATFORM_TYPE'
                        }
columns = ['APP_CODE', 'SERVER_NAME', 'ENVIRONMENT', 'PLATFORM', 'CURRENT_VERSION']


#Read the csv file and prepare the data
def read_file():
    #data = pd.read_excel("./MQ_Inventory.xlsx",sheetname='MQ installed')
    cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
                        'Port=1433'
                        'uid=DLBV0SRVMW'
                        'pwd=H1b^sTr0n%'
                         )
    #connection string to DNYSQL mdw # Brent's pseudocode
    #create cursor
    print "Connecting to sql server"
    cursor = cnxn.cursor()
    print "Connected to sql server"
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,version as CURRENT_VERSION from mw_instance WHERE software_component=MQ")
    data = pd.read_sql_query(sql,cnxn)
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    return data;

#Read the file and then for each record in the file create a dataframe column
def prep_initial():
    data = read_file()
    data = l.rename(data, renamed_columns)
    data = l.get_subet(data, columns)
    data['CURRENCY'] = data.apply(l.currency('mq'),axis=1) #Used to create the currency column - determine the currency based on the current versiion
    data['END_SUPPORT'] = data.apply(l.EOL('mq'),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['HSP_LINK'] = data.apply(l.hsp_link,axis=1)
    data['SERVER_NAME'] = data['SERVER_NAME'].str.strip()
    data = data.replace(np.nan, '', regex=True)
    data['PLATFORM_NAME'] = 'MQ'
    data['TYPE'] = 'N/A'
    data['SOURCE'] = 'N/A'
    data['DB_COUNT'] = 'N/A'
    data['INSTANCE_NM'] = 'N/A'
    print len(data);
    del data['APP_CODE']
    del data['ENVIRONMENT']
    data['SERVER_NAME'] = data['SERVER_NAME'].str.replace(' ', '')
    data['SERVER_NAME']  =  data['SERVER_NAME'].str.lower()
    data['CURRENT_VERSION']  =  data['CURRENT_VERSION'].astype(str)
    return data;

    #Check for missing dates
def check_dates(data,oldMQ):
    print "dates on new portal"
    print len(data[data['DATE'].notnull()])
    dateMiss = oldMQ[oldMQ['DATE'].notnull()].merge(data[data['DATE'].notnull()],indicator=True,on="SERVER_NAME",how='left')[['SERVER_NAME','APP_CODE','_merge']]
    dateMiss = dateMiss[dateMiss['_merge'] == 'left_only']
    dateMiss.to_csv('./mq_date_missing.csv', index=False, columns=['APP_CODE','SERVER_NAME'])
    print "dates on pervious dataset:"
    print len(oldMQ[oldMQ['DATE'].notnull()])

if __name__ == '__main__':
    data = prep_initial
    #data.to_csv('TESTMQ.csv')
    #data.to_csv('TESTMQ.csv')
