import pandas as pd
import utilites as util
import numpy as np
import logic as l
import pyodbc


#Renamed columns, these columns are used to rename columns that are different in the excel spreadsheet and it is done so that it can match the mongoDB fields
cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:PNYSQLDBA1.oak.fg.rbc.com\P105;'
                        'Port=1433'
                        'uid=PLBV0SRVMDW;'
                        'pwd=P7sTfGzr0n%;'
                         )
						 
renamed_columns={
                    'APP CODE': 'APP_CODE',
                    'Strategy':'STRATEGY' ,
                    'SERVER NAME': 'SERVER_NAME',
                    'Date': 'MIGRATION_DATE',
                    'Status':'STATUS',
                    'Comments':'COMMENT',
                    'ENV':'ENVIRONMENT',
                    'App Name':'APP_NAME',
                    'L3 Org':'L3_ORG',
                    'App Custodian':'APP_CUSTODIAN',
                    'Major Ver':'MAJOR_VERSION',
                    'Target Ver':'TARGET_VERSION', 
                    'Cr #': 'CR_NUMBER',
                    'Platform_tpye': 'PLATFORM_TYPE',
					'PLATFORM_NAME': 'PLATFORM_NAME'
                        }
columns = ['APP_CODE', 'SERVER_NAME', 'PLATFORM_NAME', 'ENVIRONMENT', 'VERSION', 'END_SUPPORT', 'CURRENT_VERSION',]

def read_file():
    cursor = cnxn.cursor()
    print "Connecting to SQL server"
    #sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT,software_component_version as VERSION, version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_SUPPORT, location, status,comments,service_window_cycle from mw_instance WHERE software_component='WebLogic' AND STATUS = 'Active' ")
    #'DATE','SERVER_NAME','COMMENTS','STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE'
    sql = ("SELECT app_app_code as APP_CODE,server_name as SERVER_NAME,environment as ENVIRONMENT, software_component as PLATFORM_NAME, version as CURRENT_VERSION, PLATFORM as platform, END_OF_SUPPORT as END_SUPPORT, location, status,comments as COMMENTS,service_window_cycle as SERVICE_WINDOW_CYCLE from mw_instance WHERE software_component='WebLogic' AND STATUS = 'Active' ")
    data = pd.read_sql_query(sql,cnxn)
    print "Connected to SQL server and Extracted data"
    print "size of file:"
    print len(data)
    data.dropna(how='all',inplace=True)
    print "size of file after droping empty rows:"
    print len(data)
    data = data.replace(np.nan, '', regex=True)
    data.to_csv('WeblogicDATAFRMMDW123.csv',encoding='utf-8')
    return data;						

def merge_iipm(iipm,data):
    data['APP_CODE'] = data['APP_CODE'].str.upper()
    iipm['APP_CODE'] = iipm['APP_CODE'].str.upper()
    data = pd.merge(data, iipm, on='APP_CODE', how='left')
    data[data['APP_CODE'].isnull()].to_csv('jboss_missing_servers.csv', index=False, columns=['SERVER_NAME','APP_CODE'])
    data = data[data['APP_CODE'].notnull()]
    print "size of file after mergin with IIPM and getting rid of inccorect servers:"
    print len(data)
    return data;

def prep_data():
    weblogic = read_file()
    weblogic = l.rename(weblogic, renamed_columns)
    weblogic = l.get_subet(weblogic, columns)
    weblogic['COMPLIANCE'] = weblogic.apply(l.compliance_check,axis=1)
    weblogic['MIGRATION_ELIGIBILITY'] = weblogic.apply(l.hsp_elg,axis=1)
    weblogic['CURRENCY'] = weblogic.apply(l.currency('webLogic'),axis=1)
    weblogic['END_SUPPORT'] = weblogic.apply(l.EOL('webLogic'),axis=1)
    weblogic['HSP_LINK'] = 'https://hsp-prod.fg.rbc.com/welcome'
    weblogic['DB_COUNT'] = "N/A"
    weblogic['SOURCE'] = "N/A"
    weblogic['TYPE'] = "N/A"
    weblogic['PLATFORM_NAME'] = "WebLogic"
    weblogic['INSTANCE_NM'] = "N/A"
    weblogic['TSS_PERCENTAGE'] = " "
    weblogic['TSS_LINK_REPORT'] = " "
    weblogic['TSS_PASS_FAIL'] = " "
    return weblogic

def curr_platform(platform='WebLogic'):
    data = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME': str(platform)})
    data = data[['DATE','SERVER_NAME','COMMENTS','STRATEGY','SERVICE_WINDOW_CYCLE','VIRP','VIRP_DATE']] #Reserve comments, strategy, and date as well as server name. We do this to keep the user inputs from one upload to another and use the server name as the KEY when merging
    return data

def update_inventory(data):
    master = util.read_mongo('dev','master_view')
    db = util._connect_mongo()
    db['master_weblogic_temp'].drop()
    util.insert_mongo(master, 'master_weblogic_temp')
    db['master_view'].delete_many({'PLATFORM_NAME':'WebLogic'})
    util.insert_mongo(data, 'master_view')

def weblogic_final():
    data = prep_data()
    iipm = util.read_mongo('dev', 'iipm')
    db = util._connect_mongo()
    data = l.rename(data, renamed_columns)
    print "size of file after mergin with servers(to get correct app code and env):"
    data = merge_iipm(iipm,data)
    oldweblogic = curr_platform()
    data = data.merge(oldweblogic,on='SERVER_NAME',how='left')
    data = data.replace(np.nan, '', regex=True)
    data.drop_duplicates(['SERVER_NAME','APP_CODE'],inplace=True)
    print "size of getting rid of duplicates:"
    print len(data)
    update_inventory(data)
    return data

if __name__ == '__main__':
    data = weblogic_final()
    print data
data.to_csv('TESTWeblogic123.csv',encoding='utf-8')
