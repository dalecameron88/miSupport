
"""Python API that is created for the Middleware Portal, this API will be used to Add/Update servers for the portal as well as provide LDAP authenication """

from flask import Flask,send_file, make_response,request
from flask_restful import Resource, Api
from flask_cors import CORS
from flask import request
import json
import pdb
import numpy as np
from flask import jsonify
from pandas.io.json import json_normalize
import pyodbc
import pandas as pd
import pandas.io.sql as psql
import re
import base64
import middlewareutilities as util
from datetime import datetime


app = Flask(__name__)
api = Api(app)

cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
                        'Port=1433'
                        'uid=DLBV0SRVMW'
                        'pwd=H1b^sTr0n%'
                         )

cursor = cnxn.cursor()


"""This method is for adding a server to the database, it takes in a json object and checks to see if a column name exists in the json object. If it does it will extract the value if not it will leave it blank..
This is because the record is being inserted into the full_inventory_table self.


The software tables are then created based off of the main table via views   """
@app.route('/api/AddServer', methods=['POST'])
def add_server():
        incoming = request.get_json()
        print incoming #obtain the incokming data
         ##Check if there is a key in the incoming json object if not present set it to 0
        if 'server_name' in incoming:
             server_name = request.json['server_name']
        else:
             server_name = ""

        if 'software_component' in incoming:
             software_component = request.json['software_component']
        else:
             software_component = ""

        if 'mv_app_code' in incoming:
            mv_app_code = request.json['mv_app_code']
        else:
            mv_app_code = ''

        if 'app_app_code' in incoming:
             app_app_code = request.json['app_app_code']
        else:
            app_app_code = ''

        if 'software_component_version' in incoming:
            software_component_version = request.json['software_component_version']
        else:
            software_component_version = ''

        if 'service_window_cycle' in incoming:
            service_window_cycle = request.json['service_window_cycle']
        else:
            service_window_cycle = ''

        if 'end_of_support' in incoming:
            end_of_support = request.json['end_of_support']
        else:
            end_of_support = ''

        if 'install' in incoming:
            install = request.json['install']
        else:
            install = ''

        if 'patch' in incoming:
            patch = request.json['patch']
        else:
            patch = ''

        if 'capped' in incoming:
            capped = request.json['capped']
        else:
            capped = ''

        if 'entitled_capacity' in incoming:
            entitled_capacity = request.json['entitled_capacity']
        else:
            entitled_capacity = ''

        if 'virtual_processor' in incoming:
            virtual_processor = request.json['virtual_processor']
        else:
            virtual_processor = ''

        if 'pvu_core' in incoming:
            pvu_core = request.json['pvu_core']
        else:
            pvu_core = ''

        if 'chargeable_core' in incoming:
            chargeable_core = request.json['chargeable_core']
        else:
            chargeable_core = ''

        if 'chargeable_pvu' in incoming:
            chargeable_pvu = request.json['chargeable_pvu']
        else:
            chargeable_pvu = ''

        if 'version' in incoming:
            version = request.json['version']
        else:
            version = ''

        if 'platform' in incoming:
            platform = request.json['platform']
        else:
            platform = ''

        if 'os' in incoming:
            os = request.json['os']
        else:
            os = ''

        if 'environment' in incoming:
            environment = request.json['environment']
        else:
            environment = ''

        if 'min_memory' in incoming:
            min_memory = request.json['min_memory']
        else:
            min_memory = ''

        if 'max_memory' in incoming:
            max_memory = request.json['max_memory']
        else:
            max_memory = ''

        if 'qmgr_name' in incoming:
            qmgr_name = request.json['qmgr_name']
        else:
            qmgr_name = ''

        if 'qmgr_port' in incoming:
            qmgr_port = request.json['qmgr_port']
        else:
            qmgr_port = ''

        if 'attestation' in incoming:
            attestation = request.json['attestation']
        else:
            attestation = ''

        if 'install_type' in incoming:
            install_type = request.json['install_type']
        else:
            install_type = ''

        if 'ha_version' in incoming:
            ha_version = request.json['ha_version']
        else:
            ha_version = ''

        if 'ha_fqdn' in incoming:
                ha_fqdn = request.json['ha_fqdn']
        else:
                ha_fqdn = ''

        if 'standby_mode' in incoming:
                standby_mode = request.json['standby_mode']
        else:
                standby_mode = ''


        if 'location' in incoming:
                location = request.json['location']
        else:
                location = ''

        if 'status' in incoming:
                status = request.json['status']
        else:
                status = ''

        if 'comments' in incoming:
                comments = request.json['comments']
        else:
                comments = ''

        if 'non_chargeable' in incoming:
                non_chargeable = request.json['non_chargeable']
        else:
                non_chargeable = ''

        if 'last_edited_by' in incoming:
            last_edited_by = datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' By: ' + request.json['last_edited_by']
        else:
            last_edited_by = ''

        id='43041'

        # platform = request.json['platform']
        cursor.execute("INSERT INTO mw_instance (server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments,non_chargeable,last_edited_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments,non_chargeable,last_edited_by))
        try:
            cnxn.commit()
            resp = '201'
        except pyodbc.Error as ex:
            sqlstate = ex.args[0] + ex.args[1]
            print(sqlstate)
            resp = '404'
        cnxn.close
        return resp

class GetServer(Resource):
    def get(self):
        args = request.args #Obtain the arguments
        server_id = args['server_id']
        print server_id
        sql = ("SELECT * FROM mw_instance WHERE srvr_inty_id=?") #Get the server based off server ID
        df = pd.read_sql_query(sql,cnxn,params=[str(server_id)])
        df = df.replace('1900-01-01','', regex=True) #Replace the 1900 dates with null
        df = df.replace('1970-01-01','', regex=True) #Replace the 1900 dates with null
        df = df.to_dict(orient='records') #Return JSON
        return jsonify({
                'summary':{
                        'total': len(df),
                        'source': 'suresh_db',
                            },
                        'results':df
            })



@app.route('/api/Login', methods=['POST'])
def login():
        test = request.headers.get('Authorization') #Obtain the HTTP Authorization header and decode it using base 64
        split = test.split(":")
        value1 = split[0].replace("Basic ","")
        value2 = split[1]
        usernamedecoded =  base64.b64decode(value1) ##Decode the values
        passwordecoded =  base64.b64decode(value2)


        address = "fg.rbc.com:3268"
        username = "MAPLE\\" + usernamedecoded #Store the decoded username into a variable
        password = passwordecoded #Store the decoded password into the variable
        return util.authenticate(address, username, password) #Pass it to the LDAP authentification method

class getGroup(Resource):
    def get(self):

            args = request.args #Obtain the arguments
            platform = args['platform']
            sql = ("SELECT * FROM access_control WHERE platform=?") #Get the server based off server ID
            df = pd.read_sql_query(sql,cnxn,params=[str(platform)])
            del df['platform']
            return list(df.values.flatten())
         #Pass it to the LDAP authentification method


class ExportAll(Resource):
    def get(self):
		args = request.args
		platform = args['platform']
			
		sql = ("SELECT * FROM mw_instance WHERE platform LIKE ?")
		df = pd.read_sql_query(sql,cnxn, params=[str(platform)])
		df = df.replace('1900-01-01','', regex=True)
		resp = make_response(df.to_csv(index=False,encoding='utf-8'))
		resp.headers["Content-Disposition"] = "attachment; filename=all_data.csv"
		resp.headers["Content-Type"] = "text/csv"
		pdb.set_trace()
		return resp
    
	
class ExportPlatform(Resource):
    def get(self):
        args = request.args #Obtain the arguments
        platform = args['platform']

        if platform == 'WAS':
            table = "was_inventory_view"
        elif platform =='DB2':
            table = "db2_inventory_view"
        elif platform =='MQ':
            table = "mq_inventory_view"

        print platform
        sql = ("SELECT * FROM " +  table  + " WHERE software_component = ?")
        df = pd.read_sql_query(sql,cnxn,params=[str(platform)])
        df = df.replace('1900-01-01','', regex=True)
        resp = make_response(df.to_csv(index=False,encoding='utf-8'))
        resp.headers["Content-Disposition"] = "attachment; filename=platform_data.csv"
        resp.headers["Content-Type"] = "text/csv"
        return resp

class GetPlatformVersionData(Resource):
    def get(self):
        args = request.args #Obtain the arguments
        platform = args['platform']

        print platform
        sql = ("SELECT version as version,count(version) as count FROM mw_instance WHERE software_component = ? GROUP BY version,software_component")
        df = pd.read_sql_query(sql,cnxn,params=[str(platform)])
        df = df.replace('1900-01-01','', regex=True)
        df = df.to_dict(orient='records') #Return JSON
        return jsonify({
                    'summary':{
                            'total': len(df),
                            'source': 'suresh_db',
                                },
                            'results':df
                })

class GetComplianceBarData(Resource):
    def get(self):
        sql = ("SELECT * from compliant_viz_data")
        df = pd.read_sql_query(sql,cnxn)
        df = df.set_index('software_component').T.to_dict()
        return jsonify({
                    'summary':{
                            'total': len(df),
                            'source': 'suresh_db',
                                },
                            'results':df
                })

class GetDashboardStats(Resource):
    def get(self):
        sql = ("SELECT software_component as platform,version,count(version) as count from mw_instance GROUP BY software_component,version ORDER BY version desc")
        df = pd.read_sql_query(sql,cnxn)
        df = df.to_dict(orient='records')
        return jsonify({
                    'summary':{
                            'total': len(df),
                            'source': 'suresh_db',
                                },
                            'results':df
                })



@app.route('/api/UpdateServer', methods=['POST'])
def update_server():

            incoming = request.get_json()
            print incoming #obtain the incokming data

             ##Check if there is a key in the incoming json object if not present set it to 0
            if 'server_name' in incoming:
                 server_name = request.json['server_name']
            else:
                 server_name = ""

            if 'software_component' in incoming:
                 software_component = request.json['software_component']
            else:
                 software_component = ""

            if 'mv_app_code' in incoming:
                mv_app_code = request.json['mv_app_code']
            else:
                mv_app_code = ''

            if 'app_app_code' in incoming:
                 app_app_code = request.json['app_app_code']
            else:
                app_app_code = ''

            if 'service_window_cycle' in incoming:
                    service_window_cycle = request.json['service_window_cycle']
            else:
                    service_window_cycle = ''

            if 'software_component_version' in incoming:
                software_component_version = request.json['software_component_version']
            else:
                software_component_version = ''

            if 'end_of_support' in incoming:
                end_of_support = request.json['end_of_support']
            else:
                end_of_support = ''

            if 'install' in incoming:
                install = request.json['install']
            else:
                install = ''

            if 'patch' in incoming:
                patch = request.json['patch']
            else:
                patch = ''

            if 'capped' in incoming:
                capped = request.json['capped']
            else:
                capped = ''

            if 'entitled_capacity' in incoming:
                entitled_capacity = request.json['entitled_capacity']
            else:
                entitled_capacity = ''

            if 'virtual_processor' in incoming:
                virtual_processor = request.json['virtual_processor']
            else:
                virtual_processor = ''

            if 'pvu_core' in incoming:
                pvu_core = request.json['pvu_core']
            else:
                pvu_core = ''

            if 'chargeable_core' in incoming:
                chargeable_core = request.json['chargeable_core']
            else:
                chargeable_core = ''

            if 'chargeable_pvu' in incoming:
                chargeable_pvu = request.json['chargeable_pvu']
            else:
                chargeable_pvu = ''

            if 'version' in incoming:
                version = request.json['version']
            else:
                version = ''

            if 'platform' in incoming:
                platform = request.json['platform']
            else:
                platform = ''

            if 'os' in incoming:
                os = request.json['os']
            else:
                os = ''

            if 'environment' in incoming:
                environment = request.json['environment']
            else:
                environment = ''

            if 'min_memory' in incoming:
                min_memory = request.json['min_memory']
            else:
                min_memory = ''

            if 'max_memory' in incoming:
                max_memory = request.json['max_memory']
            else:
                max_memory = ''

            if 'qmgr_name' in incoming:
                qmgr_name = request.json['qmgr_name']
            else:
                qmgr_name = ''

            if 'qmgr_port' in incoming:
                qmgr_port = request.json['qmgr_port']
            else:
                qmgr_port = ''

            if 'attestation' in incoming:
                attestation = request.json['attestation']
            else:
                attestation = ''

            if 'install_type' in incoming:
                install_type = request.json['install_type']
            else:
                install_type = ''

            if 'ha_version' in incoming:
                ha_version = request.json['ha_version']
            else:
                ha_version = ''

            if 'ha_fqdn' in incoming:
                    ha_fqdn = request.json['ha_fqdn']
            else:
                    ha_fqdn = ''

            if 'standby_mode' in incoming:
                    standby_mode = request.json['standby_mode']
            else:
                    standby_mode = ''


            if 'location' in incoming:
                    location = request.json['location']
            else:
                    location = ''

            if 'status' in incoming:
                    status = request.json['status']
            else:
                    status = ''

            if 'comments' in incoming:
                    comments = request.json['comments']
            else:
                    comments = ''

            if 'server_id' in incoming:
                    server_id = request.json['server_id']
            else:
                    server_id = ''

            if 'non_chargeable' in incoming:
                        non_chargeable = request.json['non_chargeable']
            else:
                        non_chargeable = ''

            if 'last_edited_by' in incoming:
                        last_edited_by = request.json['last_edited_by']
            else:
                        last_edited_by = ''

        #    cursor.execute("UPDATE mw_instance SET server_name = ?, software_component= ? where srvr_inty_id = ?", server_name,software_component,server_id)

            cursor.execute("UPDATE mw_instance SET server_name = ?,software_component = ?,mv_app_code = ?,app_app_code = ?,software_component_version = ?,service_window_cycle = ?, end_of_support = ?,install = ?,patch = ?,capped = ?,entitled_capacity = ?,virtual_processor = ?,pvu_core = ?,chargeable_core = ?,chargeable_pvu = ?,version = ?,platform = ?,os = ?,environment = ?,min_memory = ?,max_memory = ?,qmgr_name = ?,qmgr_port = ?,attestation = ?,install_type = ?,ha_version = ?,ha_fqdn = ?,standby_mode = ?,location = ?,status = ?,comments = ?, non_chargeable = ?, last_edited_by = ? where srvr_inty_id = ?", server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments,non_chargeable,last_edited_by,server_id)

            try:
                cnxn.commit()
                resp = '201'
            except pyodbc.Error as ex:
                sqlstate = ex.args[0] + ex.args[1]
                print(sqlstate)
                resp = '404'
            cnxn.close
            return resp


@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response

#api.add_resource(AddServer,'/api/AddServer')
api.add_resource(GetServer,'/api/GetServer')
api.add_resource(ExportAll,'/api/ExportAll')
api.add_resource(GetPlatformVersionData,'/api/GetPlatformData')
api.add_resource(ExportPlatform,'/api/ExportPlatform')
api.add_resource(getGroup,'/api/getGroup')
api.add_resource(GetDashboardStats,'/api/GetDashboardStats')
api.add_resource(GetComplianceBarData,'/api/GetComplianceBarData')
# running the app ...
if __name__ == '__main__':
    app.run(debug=True)
