from xml.dom import minidom
import urllib2

#doc = minidom.parse("staff.xml")
url = 'https://spcollab.fg.rbc.com/team/H13_GTI/projects/sm/_vti_bin/owssvr.dll?XMLDATA=1&List={BDB28E08-FBA9-47C8-9AC1-C211AB913F68}' # define XML location
username = 'user'
password = 'pass'
p = urllib2.HTTPPasswordMgrWithDefaultRealm()

p.add_password(None, url, username, password)

handler = urllib2.HTTPBasicAuthHandler(p)
opener = urllib2.build_opener(handler)
urllib2.install_opener(opener)

page = urllib2.urlopen(url).read()

dom = minidom.parse(urllib2.urlopen(url)) # parse the data

# doc.getElementsByTagName returns NodeList
name = doc.getElementsByTagName("name")[0]
print(name.firstChild.data)

staffs = doc.getElementsByTagName("staff")
for staff in staffs:
        sid = staff.getAttribute("id")
        nickname = staff.getElementsByTagName("nickname")[0]
        salary = staff.getElementsByTagName("salary")[0]
        print("id:%s, nickname:%s, salary:%s" %
              (sid, nickname.firstChild.data, salary.firstChild.data))
