import io
import pyodbc
import json
import time
import urllib2
import pymongo
#import cx_Oracle
import numpy as np
import pandas as pd
import pandas.io.sql as psql
from datetime import datetime
from pymongo import MongoClient
from pandas.io.json import json_normalize
import bson
import re
from pymongo.collection import ReturnDocument

cnxn = pyodbc.connect( 'Driver={SQL Server};'
						'Database=mw_inventory;'
						'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
						'Port=1433'
						'uid=DLBV0SRVMW'
						'pwd=H1b^sTr0n%'
						 )

cursor = cnxn.cursor()

def _connect_mongo(host='10.47.133.208', port=27017, username="devuser", password="devresil2018", db='dev'):
	""" A util for making a connection to mongo """
	if username and password:
		mongo_uri = 'mongodb://%s:%s@%s:%s/%s' % (username, password, host, port, db)
		conn = MongoClient(mongo_uri)
	else:
		conn = MongoClient(host, port)

	return conn[db]

def _connect_oracel(username='USPLLBV0',password='RitpPBL17LB', host_port='oc11p0-scan.fg.rbc.com:1527/pl00_prod2'):
	""" A util for making a connection to mongo """
	con = cx_Oracle.connect('USPLLBV0/RitpPBL17LBV@oc11p0-scan.fg.rbc.com:1527/pl00_prod2');
	return con

def _connect_sql(username='SCON_INV_RO',password='Password1', host='SERVER=YKE0-D2K8SWN2\IN02'):
	""" A util for making a connection to sql database """
	cnxn = pyodbc.connect('Driver={SQL Server};'
								'Server=YKE0-D2K8SWN2\IN02;'
								'Database=DYKE_DBMonitor;'
								'uid=SCON_INV_RO;pwd=Password1')
	return cnxn


def read_mongo(db, collection, query={}, host='10.47.133.208', port=27017, username="devuser", password="devresil2018",	 no_id=True, sort = False, full_text_case_insensitive_reg_search=False):
	""" Read from Mongo and Store into DataFrame """
	# Connect to MongoDB
	#import pdb;pdb.set_trace()
	#change back later??? product version
	db = _connect_mongo()
	#db = _connect_mongo(host=host, port=port, username=username, password=password, db=db)

	#parse query with full_text search arguments
	if(full_text_case_insensitive_reg_search==True):
		query = getParsedDict(query)

	# Make a query to the specific DB and Collection
	if(sort):
		cursor = db[collection].find(query).sort([("questionNoString", pymongo.DESCENDING)])
	else:
		cursor = db[collection].find(query)


	# Expand the cursor and construct the DataFrame
	df_yolo =  pd.DataFrame(list(cursor))
	# Delete the _id
	if len(df_yolo) != 0:
		if no_id:
			del df_yolo['_id']
	return df_yolo;




def read_oracel (sql):
	""" Read from oracel and Store into DataFrame """

	#connecting
	con = _connect_oracel()

	#reading sql as DataFrame...
	data = psql.read_sql(sql,con)
	data = pd.DataFrame(data)

	#closing connection
	con.close()

	return data;



def read_myops(query):
	""" Read from myOpps and Store into DataFrame """
	#requesting myOpps POST api with passing query json
	req = urllib2.Request('http://myops/api/reporting/DESexport/getDESdata')
	req.add_header('Content-Type', 'application/json')
	response = urllib2.urlopen(req, json.dumps(query))

	#reading the response
	data = response.read()


	#first time loading the the data and normalizng the source obj...
	data = json.loads(data)
	scrollID = data['scrollID']
	total = json_normalize(data['source'])
	query['scroll_id'] = str(scrollID)

	#requesting myOpps POST api with passing query json this time with query that has scroll_id
	req = urllib2.Request('http://myops/api/reporting/DESexport/getDESdata')
	req.add_header('Content-Type', 'application/json')
	response = urllib2.urlopen(req, json.dumps(query))

	checkSize = True;
	# keep scroling untill there is no data left (this is elasticsearch back-end)
	while checkSize:
		#reading the response
		data = response.read()

		#loading the the data and normalizng the source obj...
		response = urllib2.urlopen(req, json.dumps(query))
		data = json.loads(data)
		if len(data['source']) == 0:
			checkSize = False;

		if checkSize:
			data = json_normalize(data['source'])
			total = total.append(data, ignore_index=True)
	return total


def read_HSPALL():
	""" Read from HSP API and Store into DataFrame """

	#requesting HSP GET api with passing token given
	req = urllib2.Request('https://hsp-prod.fg.rbc.com/rs/forms/listMyOpenTickets?token=Qnwe5L1Sl8Q1OsXwyC/x7x5xPprcdYh2')
	response = urllib2.urlopen(req)
	data = response.read()

	#converting into dataframe...
	data = json.loads(data)
	data = pd.DataFrame(data['aaData'])

	return data;


def read_HSPFULL():
	""" Read from HSP API and Store into DataFrame (for each ticket full...) """
	objs = []
	#reading all hsps tickets open and getting the ids as a list...
	data = read_HSPALL();
	ids = data['id'].tolist();

	#itterating through ids to go to each respected ticket to get the full info...
	for elem in ids:
		#requesting HSP GET api with passing token given and id retrived...
		url = 'https://hsp-prod.fg.rbc.com/rs/forms/ticketDetails?token=Qnwe5L1Sl8Q1OsXwyC/x7x5xPprcdYh2&id='+ elem
		req = urllib2.Request(url)
		response = urllib2.urlopen(req)
		data = response.read()

		#converting into dataframe...
		data = json.loads(data)
		objs.append(data)
	data = pd.DataFrame(objs)
	return data;

def update_usrinput(data,collection,key='_id'):
	""" A util for updating mongo --kri db default--  """
	#bulk objs to be updated
	objs = []
	client = _connect_mongo()
	#table to be connected
	coll = client[collection];

	print ('this is the data')
	print data
	counter = 0
	status = []
	for index, row in data.iterrows():
		obj = row.to_json();
		obj = json.loads(obj.decode("utf-8","ignore"));

		counter+=1

		if 'DATE' in obj:

			 print obj['DATE']
			 if obj['DATE'] == None:
			  print 'No date entered'
			 else:
				 print 'entered else'
				 datestatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'DATE': obj['DATE']}},return_document= ReturnDocument.AFTER)
				 print datestatus['DATE']
				 print obj['DATE']
				 if datestatus['DATE'] == obj['DATE']:
					 print 'Date was updated'
					 status.append(obj[key] + ' updated')
				 else:
					 status.append(obj[key] + ' not updated')

				 print counter
		else:
		  print 'No date in object'

		if 'COMMENTS' in obj:
			if obj['COMMENTS'] == None:
			  print 'No comments entered'
			else:
			   commentstatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'COMMENTS': str(obj['COMMENTS']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
			   if commentstatus['COMMENTS'].encode('utf-8') == obj['COMMENTS'].encode('utf-8'):
				   print 'Comments was updated'
				   print commentstatus['COMMENTS']
				   print obj['COMMENTS']
				   status.append(obj[key] + ' updated')
			   else:
				   status.append(obj[key] + ' not updated')
		else:
			print 'No comments in object'			
			
		if 'SERVICE_WINDOW_CYCLE' in obj:
			if obj['SERVICE_WINDOW_CYCLE'] == None:
			  print 'No comments entered'
			else:
			   servicewindowstatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'SERVICE_WINDOW_CYCLE': str(obj['SERVICE_WINDOW_CYCLE']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
			   cursor.execute("UPDATE mw_instance SET SERVICE_WINDOW_CYCLE = ?",SERVICE_WINDOW_CYCLE)
			   if servicewindowstatus['SERVICE_WINDOW_CYCLE'].encode('utf-8') == obj['SERVICE_WINDOW_CYCLE'].encode('utf-8'):
				   print 'SERVICE_WINDOW_CYCLE was updated'
				   print 'SQL Database Updated'
				   cnxn.commit()
				   resp = '201'
				   status.append(obj[SERVER_NAME] + ' updated')
				   
		if 'STRATEGY' in obj:
			if obj['STRATEGY'] == None:
			  print 'No strategy entered'
		else:
			   strategystatus = coll.find_one_and_update({key : bson.ObjectId(obj[key])}, {'$set': {'STRATEGY': str(obj['STRATEGY']).encode('utf-8')}},return_document= ReturnDocument.AFTER)
			   if strategystatus['STRATEGY'].encode('utf-8') == obj['STRATEGY'].encode('utf-8'):
					 print strategystatus['STRATEGY']
					 print obj['STRATEGY']
					 status.append(obj[key] + ' updated')
			   else:
					 status.append(obj[key] + ' not updated')
					 
def read_sql(sql,con):
	""" Read from oracel and Store into DataFrame """

	#con  = _connect_sql();
	#passing con and sql query to return result as DataFrame
	data = psql.read_sql(sql, con)

	#replacing all the null values with empty string
	data = data.replace(np.nan, '', regex=True)

	#closing connection
	con.close()

	return data


def insert_mongo(data,collection):
	""" A util for inserting mongo --kri db default--  """
	#bulk objs to be updated
	objs = []
	client = _connect_mongo()

	#table to be connected
	db = client[collection];
	for index, row in data.iterrows():
		obj = row.to_json();
		obj = json.loads(obj.decode("utf-8","ignore"));
		obj["LAST_UPDATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		#print obj;
		objs.append(obj);
	db.insert(objs);
	print 'inserted...'

def remove_mongo(collName='master_view',itemName='', field='PLATFORM_NAME'):
	""" A util for removeing from collection --kri db default--	 """
	db = _connect_mongo()
	coll = db[collName];
	coll.delete_many ({field:itemName});
	return itemName + ' removed from ' + collName

def upsert_mongo(data,collection,key='SERVER_NAME'):
	""" A util for updating mongo --kri db default--  """
	#bulk objs to be updated
	objs = []
	client = _connect_mongo()
	# client = _connect_mongo()

	#table to be connected
	coll = client[collection];
	bulk = coll.initialize_unordered_bulk_op();

	for index, row in data.iterrows():
		obj = row.to_json();
		obj = json.loads(obj.decode("utf-8","ignore"));
		obj["LAST_UPDATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		bulk.find({key : obj[key]}).upsert().update({'$set':obj})
	bulk.execute()
	print 'upserted..'
