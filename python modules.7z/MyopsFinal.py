
# coding: utf-8

# In[1]:

import utilites as util
import pandas as pd
from pymongo import MongoClient
from pymongo.collection import ReturnDocument
from datetime import datetime, date
from pandas.io.json import json_normalize
import re
import logic as l
import numpy as np
pd.options.mode.chained_assignment = None
import json
import bson
import sys
reload(sys)
sys.setdefaultencoding('utf8')


# In[2]:
#Renamed columns, these columns are used to rename columns that are different in the excel spreadsheet and it is done so that it can match the mongoDB fields
additional_columns = {
                        'MIGRATION_ELIGIBILITY': [False],
                        'HSP_LINK' : [''],
                        'CURRENCY' : ['N/A'],
                        'END_SUPPORT': ['N/A'],
                        }
renamed_columns={
                        'serverFinancialAppCode': 'APP_CODE',
                        'platformType':'PLATFORM_TYPE' ,
                        'serverName': 'SERVER_NAME',
                        'environment': 'ENVIRONMENT',
                        'machineType':'TYPE',
                        'operatingSystem':'FULL_VERSION',
                    }
intial_columns=[
                        'serverFinancialAppCode',
                        'serverMonitoringAppCode',
                        'serverName',
                        'environment',
                        'machineType',
                        'operatingSystem',
                        'platformType'
                ]


client = util._connect_mongo()
coll2 = client['myops'];




# In[3]:
def app_code(row):
    if not str(row['serverMonitoringAppCode']):
        return row['serverFinancialAppCode'].upper();
    else:
        return row['serverMonitoringAppCode'].upper();

def paltform_type(row):
    """A util to parse operatingSystem name and return the version """
    if 'Windows' in str(row['operatingSystem']) :
        return 'Windows'

    elif 'AIX' in str(row['operatingSystem']):
        return 'AIX';

    elif 'Red Hat' in str(row['operatingSystem']) :
        return 'Red Hat';

    elif 'Linux' in str(row['operatingSystem']) :
        return 'Red Hat';

    elif 'Linux Red Hat' in str(row['operatingSystem']) :
            return 'Red Hat';

    elif 'Solaris' in str(row['operatingSystem']):
        return 'Solaris';

    else:
        return 'N/A';


# In[4]:

iipm = util.read_mongo('dev','iipm') #Read IIPM for the correct appCodes
master_view = util.read_mongo('dev','myops') #Read IIPM for the correct appCodes
iipm['APP_CODE'] = iipm.APP_CODE.str.upper()


# In[10]:

#ElasticSearch query used to obtan the server information
def myops_intial():
    print 'Connecting to Mongo'
    data = util.read_mongo('dev', 'myops')
    return data


#Create dataframe columns based on platform and parameters passed
def prep_platform(data, platform):
    #odd case ; windows
    if platform == 'windows':
        data['CURRENT_VERSION'].replace('2003,', '2003',inplace=True)
    elif platform == 'Solaris':
        platform = 'solaris'

    data['CURRENCY'] = data.apply(l.currency(platform),axis=1)
    data['END_SUPPORT'] = data.apply(l.EOL(platform),axis=1)
    data['COMPLIANCE'] = data.apply(l.compliance_check,axis=1)
    data['MIGRATION_ELIGIBILITY'] = data.apply(l.hsp_elg,axis=1)
    data['HSP_LINK'] = data.apply(l.hsp_link,axis=1)

    del data['PLATFORM_TYPE']
    del data['FULL_VERSION']
    del data['serverMonitoringAppCode']

    data = data.replace(np.nan, '', regex=True)
    print "size of the platform after giving logics(prep_platform):"
    print len(data)
    return data;



def platform_inv(data,platform):
    data = data.loc[data['PLATFORM_NAME'] == platform] #Search the data based on the platform that was passed
    print "size based on platform"
    print len(data)

    data['CURRENT_VERSION'] = data.apply(l.parse(platform.replace(' ','').lower()),axis=1)

    data = prep_platform(data, platform.replace(' ','').lower())
    data = data.loc[data['APP_CODE'] != '' ]
    print "size of the platform after getting rid of empty app code:"
    print len(data)
    # data['APP_CODE'] = data['APP_CODE'].str.capitalize()
    if platform != 'Windows':
        data = pd.merge(data, iipm, on='APP_CODE', how='left')
    print "size of the platform after merging with IIPM:( with App Code)"
    print len(data[data['APP_CODE'].notnull()])
    print "size of the platform after merging with IIPM:( without correct App Code)"
    print len(data[data['APP_CODE'].isnull()])
    data = data.replace(np.nan, '', regex=True)
    print 'size of ' + platform + ' after everything is: ' + str(len(data));
    return data;



data = myops_intial()


# In[11]:


#Windows MyOps Method - used to obtain windows servers information from my ops
def windows_final(data, key='SERVER_NAME'):
      #bulk objs to be updated
     #bulk objs to be updated
    objs = []
    client = util._connect_mongo()
    coll = client['master_view'];
    coll2 = client['myops'];
    #table to be connected

    aix = platform_inv(data,'Windows')
    myopsdata = aix[['SERVER_NAME', 'APP_CODE', 'ipAddress']]
    #myops = myopsdata[myopsdata['ipAddress'].str.contains("10.241", na=False)]
    pat = re.compile('10.101')
    #pat2 = re.compile('10.101')
    #myops = coll2.find_one({ "ipAddress": {'$regex': pat}})
    myops = pd.DataFrame(list(coll2.find({ "ipAddress": {'$regex': '10.101'}, "FULL_VERSION": {'$regex': 'Microsoft Windows Server 2016 Standard'}})))
    #myops2 = pd.DataFrame(list(coll2.find({ "FULL_VERSION": {'$regex': pat2}})))
    #myops = pd.concat([myops,myops2])#Microsoft Windows Server 2012 R2 Standard
    print myops
    #del myops['_id']
    #myops = pd.merge(myops, master_view, on='SERVER_NAME', how='right')
    #del myops['binary']
    #pat = re.compile('10.131.')
    #pat = re.compile('10.241')
    #myopsdataip = coll2.find({ "ipAddress": {'$regex': pat}})
    #print myopsdataip['ipAddress']
    #result = []
    #for each in myopsdataip:
    #    result.append(myopsdataip['ipAddress'])
    #    print result[0]    df.columns=df.columns.str.replace('#','')
	
    for index, row in myops.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));
	obj['ipAddress'] = pd.Series(['ipAddress']).str.replace(':','') #.replace({r'[^\x00-\x7F]+':''}, regex=True, inplace=True)
	print obj['ipAddress']
	print obj['SERVER_NAME']
	print obj['FULL_VERSION']
        #myopsdataip = coll2.find_one({ "ipAddress": {'$regex': pat}})
        #print obj['ipAddress']
        #result = []
        #for each in myopsdataip:
        #    result.append(myopsdataip['ipAddress'])
        #    print result[0]
	    #obj['ipAdress'] = myopsdataip
        
	if 'ipAddress' in obj:
	    print 'Retrieving ipAddresses'
	    print obj['ipAddress']
	    print 'Retrieved ipAddress from myops'
	    print obj['FULL_VERSION']
	    #print myopsdataip
		     
	    if 'SERVER_NAME' in obj:
					print 'Setting VIRP status'
					virpstatus = coll.find_one_and_update({key : obj['SERVER_NAME']}, {'$set': {'VIRP': 'Yes'}},return_document= ReturnDocument.AFTER)
					print 'After setting VIRP'
					if coll.find({key : obj[key]}, {'$lte': {'VIRP_DATE': ' '}}):
					    #print obj[key]
					    print 'setting VIRP DATE'
					    obj["VIRP_DATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
					    print 'VIRP date set'
					    coll.find_one_and_update({key : obj[key]}, {'$set': {'VIRP_DATE': obj['VIRP_DATE']}})
					    #print 'Update Mongo VIRP Column'
		                        else:
                                            print ' VIRP DATE already set'
    else:
	   print 'None Found'
	
    myops['PLATFORM_NAME'] = 'Windows'
    myops['SOURCE'] = 'N/A'
    myops['DB_COUNT'] = 'N/A'
    myops['INSTANCE_NM'] = 'N/A'
    myops['SERVER_NAME']  =  data['SERVER_NAME'].str.lower()
    db = util._connect_mongo()
    db['myops_windows'].drop()
    myops = windows.replace(np.nan, '', regex=True)
    util.insert_mongo(myops,'myops_windows') #Create the windows view contains windows servers obtained from myOps
	
	   
    return myops	   

#Redhat MyOps Method - used to obtain Redhat servers information from my ops
def redhat_final(data):
    redhat = platform_inv(data,'Red Hat')
    print 'redhat:'
    redhat = redhat.replace(np.nan, '', regex=True)
    redhat['TYPE'] = 'N/A'
    redhat['SOURCE'] = 'N/A'
    redhat['DB_COUNT'] = 'N/A'
    redhat['PLATFORM_NAME'] = 'REDHAT'
    redhat['INSTANCE_NM'] = 'N/A'
    redhat.drop_duplicates('SERVER_NAME',inplace=True);
    conn = util._connect_mongo()
    db = conn['redhat_views']
    db.drop()
    util.insert_mongo(redhat,'redhat_views')
    return redhat;

#Solaris MyOps Method - used to obtain Solaris servers information from my ops
def solaris_final(data):
    solaris = platform_inv(data,'Solaris')
    print 'solaries:'
    solaris['TYPE'] = 'N/A'
    solaris['SOURCE'] = 'N/A'
    solaris['DB_COUNT'] = 'N/A'
    solaris['PLATFORM_NAME'] = 'SOLARIS'
    solaris['HSP_LINK'] =  'N/A'
    solaris['INSTANCE_NM'] = 'N/A'
    solaris.drop_duplicates('SERVER_NAME', inplace=True);
    db = util._connect_mongo()
    db['solaris_views'].drop()
    util.insert_mongo(solaris,'solaris_views')
    print len(solaris.columns.values)
    print solaris.columns.values
    print len(solaris)
    return solaris

if __name__ == '__main__':
    data1 = windows_final(data, key='SERVER_NAME')
    data1.to_csv('TESTmyops123.csv',encoding='utf-8',index=None)