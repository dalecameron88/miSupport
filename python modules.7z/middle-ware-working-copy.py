
"""Python API that is created for the Middleware Portal, this API will be used to Add/Update servers for the portal as well as provide LDAP authenication """

from flask import Flask,send_file, make_response,request
from flask_restful import Resource, Api
from flask_cors import CORS
from flask import request
import json
import middlewareutilities as util
import numpy as np
from flask import jsonify
from pandas.io.json import json_normalize
import pyodbc
import pandas as pd
import pandas.io.sql as psql
import re
import base64

app = Flask(__name__)
api = Api(app)


cnxn = pyodbc.connect('Driver={SQL Server};'
                    'Database=mw_inventory;'
                        'Server=NJDBWIND105\D105;'
                        'username=DLBV0SRVMW'
						'password=H1b^sTr0n%')



cursor = cnxn.cursor()


"""This method is for adding a server to the database, it takes in a json object and checks to see if a column name exists in the json object. If it does it will extract the value if not it will leave it blank..
This is because the record is being inserted into the full_inventory_table self.


The software tables are then created based off of the main table via views   """
class AddServer(Resource):
  def post(self):
        incoming = request.get_json()
        print incoming #obtain the incokming data


         ##Check if there is a key in the incoming json object if not present set it to 0
        if 'server_name' in incoming:
             server_name = request.json['server_name']
        else:
             server_name = ""

        if 'software_component' in incoming:
             software_component = request.json['software_component']
        else:
             software_component = ""

        if 'mv_app_code' in incoming:
            mv_app_code = request.json['mv_app_code']
        else:
            mv_app_code = ''

        if 'app_app_code' in incoming:
             app_app_code = request.json['app_app_code']
        else:
            app_app_code = ''

        if 'software_component_version' in incoming:
            software_component_version = request.json['software_component_version']
        else:
            software_component_version = ''

        if 'service_window_cycle' in incoming:
            service_window_cycle = request.json['service_window_cycle']
        else:
            service_window_cycle = ''

        if 'end_of_support' in incoming:
            end_of_support = request.json['end_of_support']
        else:
            end_of_support = ''

        if 'install' in incoming:
            install = request.json['install']
        else:
            install = ''

        if 'patch' in incoming:
            patch = request.json['patch']
        else:
            patch = ''

        if 'capped' in incoming:
            capped = request.json['capped']
        else:
            capped = ''

        if 'entitled_capacity' in incoming:
            entitled_capacity = request.json['entitled_capacity']
        else:
            entitled_capacity = ''

        if 'virtual_processor' in incoming:
            virtual_processor = request.json['virtual_processor']
        else:
            virtual_processor = ''

        if 'pvu_core' in incoming:
            pvu_core = request.json['pvu_core']
        else:
            pvu_core = ''

        if 'chargeable_core' in incoming:
            chargeable_core = request.json['chargeable_core']
        else:
            chargeable_core = ''

        if 'chargeable_pvu' in incoming:
            chargeable_pvu = request.json['chargeable_pvu']
        else:
            chargeable_pvu = ''

        if 'version' in incoming:
            version = request.json['version']
        else:
            version = ''

        if 'platform' in incoming:
            platform = request.json['platform']
        else:
            platform = ''

        if 'os' in incoming:
            os = request.json['os']
        else:
            os = ''

        if 'environment' in incoming:
            environment = request.json['environment']
        else:
            environment = ''

        if 'min_memory' in incoming:
            min_memory = request.json['min_memory']
        else:
            min_memory = ''

        if 'max_memory' in incoming:
            max_memory = request.json['max_memory']
        else:
            max_memory = ''

        if 'qmgr_name' in incoming:
            qmgr_name = request.json['qmgr_name']
        else:
            qmgr_name = ''

        if 'qmgr_port' in incoming:
            qmgr_port = request.json['qmgr_port']
        else:
            qmgr_port = ''

        if 'attestation' in incoming:
            attestation = request.json['attestation']
        else:
            attestation = ''

        if 'install_type' in incoming:
            install_type = request.json['install_type']
        else:
            install_type = ''

        if 'ha_version' in incoming:
            ha_version = request.json['ha_version']
        else:
            ha_version = ''

        if 'ha_fqdn' in incoming:
                ha_fqdn = request.json['ha_fqdn']
        else:
                ha_fqdn = ''

        if 'standby_mode' in incoming:
                standby_mode = request.json['standby_mode']
        else:
                standby_mode = ''


        if 'location' in incoming:
                location = request.json['location']
        else:
                location = ''

        if 'status' in incoming:
                status = request.json['status']
        else:
                status = ''

        if 'comments' in incoming:
                comments = request.json['comments']
        else:
                comments = ''


        # platform = request.json['platform']
        cursor.execute("INSERT INTO mw_instance (server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments))
        try:
            cnxn.commit()
            resp = 201
        except pyodbc.Error as ex:
            sqlstate = ex.args[0] + ex.args[1]
            print(sqlstate)
            resp = 404
        cnxn.close
        return resp

class GetServer(Resource):
    def get(self):
        args = request.args #Obtain the arguments
        server_id = args['server_id']
        print server_id
        sql = ("SELECT * FROM mw_instance WHERE srvr_inty_id=?") #Get the server based off server ID
        df = pd.read_sql_query(sql,cnxn,params=[str(server_id)])
        df = df.replace('1900-01-01','', regex=True) #Replace the 1900 dates with null
        df = df.to_dict(orient='records') #Return JSON
        return jsonify({
                'summary':{
                        'total': len(df),
                        'source': 'suresh_db',
                            },
                        'results':df
            })

class login(Resource):
    def post(self):


        test = request.headers.get('Authorization') #Obtain the HTTP Authorization header and decode it using base 64
        split = test.split(":")
        value1 = split[0].replace("Basic ","")
        value2 = split[1]
        usernamedecoded =  base64.b64decode(value1) ##Decode the values
        passwordecoded =  base64.b64decode(value2)


        address = "fg.rbc.com:3268"
        username = "MAPLE\\" + usernamedecoded #Store the decoded username into a variable
        password = passwordecoded #Store the decoded password into the variable
        return authenticate(address, username, password) #Pass it to the LDAP authentification method
        return 201




class ExportAll(Resource):
    @app.route('/fullinventory')
    def get(self):
        incoming = request.get_json()

        print incoming
        if 'servername' in incoming:
        params = tuple(flatten((servername)))
        # = request.json['servername']
        sql = ("SELECT * FROM mw_instance WHERE server_name = ?")
        #df = pd.read_sql_query(sql,cnxn,params=[str(incoming)])
        df = pd.read_sql_query(sql,cnxn,params=[str(incoming)])
        df = df.replace('1900-01-01','', regex=True)
        resp = make_response(df.to_csv(index=False))
        resp.headers["Content-Disposition"] = "attachment; filename=all_data.csv"
        resp.headers["Content-Type"] = "text/csv"

        return resp




class UpdateServer(Resource):
        def post(self):

            incoming = request.get_json()
            print incoming #obtain the incokming data

             ##Check if there is a key in the incoming json object if not present set it to 0
            if 'server_name' in incoming:
                 server_name = request.json['server_name']
            else:
                 server_name = ""

            if 'software_component' in incoming:
                 software_component = request.json['software_component']
            else:
                 software_component = ""

            if 'mv_app_code' in incoming:
                mv_app_code = request.json['mv_app_code']
            else:
                mv_app_code = ''

            if 'app_app_code' in incoming:
                 app_app_code = request.json['app_app_code']
            else:
                app_app_code = ''

            if 'service_window_cycle' in incoming:
                    service_window_cycle = request.json['service_window_cycle']
            else:
                    service_window_cycle = ''

            if 'software_component_version' in incoming:
                software_component_version = request.json['software_component_version']
            else:
                software_component_version = ''

            if 'end_of_support' in incoming:
                end_of_support = request.json['end_of_support']
            else:
                end_of_support = ''

            if 'install' in incoming:
                install = request.json['install']
            else:
                install = ''

            if 'patch' in incoming:
                patch = request.json['patch']
            else:
                patch = ''

            if 'capped' in incoming:
                capped = request.json['capped']
            else:
                capped = ''

            if 'entitled_capacity' in incoming:
                entitled_capacity = request.json['entitled_capacity']
            else:
                entitled_capacity = ''

            if 'virtual_processor' in incoming:
                virtual_processor = request.json['virtual_processor']
            else:
                virtual_processor = ''

            if 'pvu_core' in incoming:
                pvu_core = request.json['pvu_core']
            else:
                pvu_core = ''

            if 'chargeable_core' in incoming:
                chargeable_core = request.json['chargeable_core']
            else:
                chargeable_core = ''

            if 'chargeable_pvu' in incoming:
                chargeable_pvu = request.json['chargeable_pvu']
            else:
                chargeable_pvu = ''

            if 'version' in incoming:
                version = request.json['version']
            else:
                version = ''

            if 'platform' in incoming:
                platform = request.json['platform']
            else:
                platform = ''

            if 'os' in incoming:
                os = request.json['os']
            else:
                os = ''

            if 'environment' in incoming:
                environment = request.json['environment']
            else:
                environment = ''

            if 'min_memory' in incoming:
                min_memory = request.json['min_memory']
            else:
                min_memory = ''

            if 'max_memory' in incoming:
                max_memory = request.json['max_memory']
            else:
                max_memory = ''

            if 'qmgr_name' in incoming:
                qmgr_name = request.json['qmgr_name']
            else:
                qmgr_name = ''

            if 'qmgr_port' in incoming:
                qmgr_port = request.json['qmgr_port']
            else:
                qmgr_port = ''

            if 'attestation' in incoming:
                attestation = request.json['attestation']
            else:
                attestation = ''

            if 'install_type' in incoming:
                install_type = request.json['install_type']
            else:
                install_type = ''

            if 'ha_version' in incoming:
                ha_version = request.json['ha_version']
            else:
                ha_version = ''

            if 'ha_fqdn' in incoming:
                    ha_fqdn = request.json['ha_fqdn']
            else:
                    ha_fqdn = ''

            if 'standby_mode' in incoming:
                    standby_mode = request.json['standby_mode']
            else:
                    standby_mode = ''


            if 'location' in incoming:
                    location = request.json['location']
            else:
                    location = ''

            if 'status' in incoming:
                    status = request.json['status']
            else:
                    status = ''

            if 'comments' in incoming:
                    comments = request.json['comments']
            else:
                    comments = ''

            if 'server_id' in incoming:
                    server_id = request.json['server_id']
            else:
                    server_id = ''

            print server_id

        #    cursor.execute("UPDATE mw_instance SET server_name = ?, software_component= ? where srvr_inty_id = ?", server_name,software_component,server_id)

            cursor.execute("UPDATE mw_instance SET server_name = ?,software_component = ?,mv_app_code = ?,app_app_code = ?,software_component_version = ?,service_window_cycle = ?, end_of_support = ?,install = ?,patch = ?,capped = ?,entitled_capacity = ?,virtual_processor = ?,pvu_core = ?,chargeable_core = ?,chargeable_pvu = ?,version = ?,platform = ?,os = ?,environment = ?,min_memory = ?,max_memory = ?,qmgr_name = ?,qmgr_port = ?,attestation = ?,install_type = ?,ha_version = ?,ha_fqdn = ?,standby_mode = ?,location = ?,status = ?,comments = ? where srvr_inty_id = ?", server_name,software_component,mv_app_code,app_app_code,software_component_version,service_window_cycle,end_of_support,install,patch,capped,entitled_capacity,virtual_processor,pvu_core,chargeable_core,chargeable_pvu,version,platform,os,environment,min_memory,max_memory,qmgr_name,qmgr_port,attestation,install_type,ha_version,ha_fqdn,standby_mode,location,status,comments,server_id)

            try:
                cnxn.commit()
                resp = 201
            except pyodbc.Error as ex:
                sqlstate = ex.args[0] + ex.args[1]
                print(sqlstate)
                resp = 404
            cnxn.close
            return resp



@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response

api.add_resource(AddServer,'/api/AddServer')
api.add_resource(GetServer,'/api/GetServer')
api.add_resource(UpdateServer,'/api/UpdateServer')
api.add_resource(login,'/api/Login')
api.add_resource(ExportAll,'/api/ExportAll')


# running the app ...
if __name__ == '__main__':
    app.run(debug=True)
