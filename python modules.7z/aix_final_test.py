#AIX MyOps Method - used to obtain AIX servers information from my ops
def aix_final(data, key='SERVER_NAME'):
    #bulk objs to be updated
    objs = []
    client = util._connect_mongo()
    coll = client['master_view'];
    #table to be connected
    oldAIX = util.read_mongo('dev', 'master_view', query={'PLATFORM_NAME':'AIX'})
    oldAixDetails = oldAIX
    oldAIX = oldAIX[['SERVER_NAME','VIRP','VIRP_DATE']]
	
    aix = platform_inv(data,'AIX')
    myopsdata = aix[['SERVER_NAME', 'APP_CODE', 'ipAddress']]
    aixdata = oldAIX.merge(myopsdata, on=['SERVER_NAME'], how='left', indicator=True)
    
    #print "This is AIX data"
    #print aixdata

    #myopsandaix = tmp[tmp['_merge'] == 'left_only']
    #myopsandaix = myopsandaix[['SERVER_NAME', 'VIRP', 'VIRP_DATE']]
    #print myopsandaix[['SERVER_NAME']]
    ipAddrSearch = '10.241'
    #pat = re.compile(r"^(10?[-. ]?(\d+))$")
    pat = re.compile('10(.+?)241')
    print 'aix:'
    aix = aix.replace(np.nan, '', regex=True)
    #myopsdata = aix[['SERVER_NAME', 'APP_CODE', 'ipAddress']]
    #aixdata = aix['ipAddress']
    for index, row in aixdata.iterrows():
        obj = row.to_json();
        obj = json.loads(obj.decode("utf-8","ignore"));
	#aix['ipAddress'] = myopsdata[myopsdata['ipAddress'].dropna().str.contains("10.241", na=False)]
    aixdata = aixdata[aixdata['ipAddress'].dropna().str.contains("10.241", na=False)]	
	#print aix['ipAddress']
    print 'test three columns'
    print aixdata
    if 'ipAddress' in obj:
		    #print aix['ipAddress']
		    if 'SERVER_NAME' in obj:
					obj['ipAddress'] = aix['ipAddress']
					obj['SERVER_NAME'] = aix['SERVER_NAME'] 
					#print obj['ipAddress']
					#print obj['SERVER_NAME']
					obj[key]=str(aix['SERVER_NAME'])
					#print obj[key]
					#obj['SERVER_NAME'].replace(np.nan, '', regex=True)
					#dataframewith10SERVER.replace(np.nan, '', regex=True)
					#print 'this is the ipAddress for corresponding SERVER_NAME'
					#print dataframewith10
					#print 'this is the SERVER_NAME for corresponding IP'
					#print dataframewith10SERVER
					#dataframewith10SERVER = myopsdata['SERVER_NAME']
					print 'setting VIRP status'
					#print obj[key]
					virpstatus = coll.find_one_and_update({key : obj[key]}, {'$set': {'VIRP': 'Yes'}},return_document= ReturnDocument.AFTER)
					print 'VIRP status set'
					#virpstatusdate = coll.find({key : obj[key]}, {'$gt': {'VIRP_DATE': 1}},return_document= ReturnDocument.AFTER)
					#print virpstatusdate
					if coll.find({key : obj[key]}, {'$lte': {'VIRP_DATE': ' '}}):
					    #print obj[key]
					    print 'setting VIRP DATE'
					    obj["VIRP_DATE"] =  datetime.now().strftime('%Y-%m-%d %H:%M:%S')
					    print 'VIRP date set'
					    coll.find_one_and_update({key : obj[key]}, {'$set': {'VIRP_DATE': obj['VIRP_DATE']}})
					    #print 'Update Mongo VIRP Column'
		                        else:
                                            print ' VIRP DATE already set'
		    else:
                         print 'None Found'			
    else:
	   print 'None Found'
	   
    return aixdata