# -*- coding: utf-8 -*-
"""
Created on Tue Apr 10 12:04:41 2018

@author: 198242216
"""

import json
import numpy as np
from flask import jsonify
from pandas.io.json import json_normalize
import pyodbc
import pandas as pd
import pandas.io.sql as psql
import re
import base64


cnxn = pyodbc.connect( 'Driver={SQL Server};'
                        'Database=mw_inventory;'
                        'Server=tcp:DNYSQLDBA1.oak.fg.rbc.com\D105;'
                        'Port=1433'
                        'uid=DLBV0SRVMW'
                        'pwd=H1b^sTr0n%'
                         )

cursor = cnxn.cursor()

#sql = ("DELETE FROM reporting_data")
#deleteData = pd.sql.execute(sql,cnxn)


#Get the total number of patch servers per platform
#sql = ("SELECT software_component,software_component_version,count(software_component_version) as totalNumberOfServersOnPatch,version FROM mw_instance WHERE install_type='MQ SERVER' and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  or install_type IS NULL and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)','HP/UX') GROUP BY software_component_version,software_component,version")
sql = ("SELECT software_component,software_component_version,count(software_component_version) as totalNumberOfServersOnPatch,version FROM mw_instance WHERE status NOT IN ('Decommissioned') OR  install_type='MQ SERVER' and status NOT IN ('Decommissioned') GROUP BY software_component_version,software_component,version")
patchData = pd.read_sql_query(sql,cnxn)


#Get the total number of major servers per platform
#majorsqldata = ("SELECT software_component,version,count(version) as numberOfServersOnMajorVersion,install_type,status FROM mw_instance WHERE install_type='MQ SERVER' and status NOT IN ('Decommissioned') and software_component='MQ' and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  or install_type IS NULL and status NOT IN ('Decommissioned') and platform NOT IN ('z/OS', 'HP NSK (Tandem)', 'HP/UX')  GROUP BY version,software_component,install_type,status")
majorsqldata = ("SELECT software_component,version,count(version) as numberOfServersOnMajorVersion,install_type,status FROM mw_instance WHERE status NOT IN ('Decommissioned')  OR install_type='MQ SERVER' and status NOT IN ('Decommissioned') GROUP BY version,software_component,install_type,status")
majordata = pd.read_sql_query(majorsqldata,cnxn)


#Get the total number of total number of servers per platform
totalplatform = ("SELECT software_component as software_component_x, count(software_component) as totalservers FROM mw_instance  WHERE status NOT IN ('Decommissioned') OR install_type='MQ SERVER' and status NOT IN ('Decommissioned') GROUP BY software_component")
totalplatform = pd.read_sql_query(totalplatform,cnxn)

newdata = patchData.merge(majordata,on='version')
del newdata['software_component_y'] #Delete the duplicate column

newdata = totalplatform.merge(newdata,on='software_component_x') ##Merge on the software component ex. MQ, DB2



newdata = newdata.rename(columns={'software_component_x': 'software_component'})

#For each row determine the percentages
newdata['patch_ver_percentage'] = newdata.apply(lambda row: str(round(int(row['totalNumberOfServersOnPatch'])/float(row['numberOfServersOnMajorVersion'])*100,1)) if row['numberOfServersOnMajorVersion'] !=0 else 0.0,axis=1)
newdata['major_ver_percentage'] = newdata.apply(lambda row: str(round(int(row['totalNumberOfServersOnPatch'])/float(row['totalservers'])*100,1)) if row['numberOfServersOnMajorVersion'] !=0 else 0.0,axis=1)



#Insert the dataframe into the SQL database 
for index,row in newdata.iterrows():
     cursor.execute("INSERT INTO reporting_data (software_component,software_component_version,total_number_patch_ver,version,total_number_maj_ver,percentage_patch,percentage_major) VALUES (?,?,?,?,?,?,?)",
     str(row['software_component']),str(row['software_component_version']),str(row['totalNumberOfServersOnPatch']),str(row['version']),str(row['numberOfServersOnMajorVersion']),str(row['patch_ver_percentage']),str(row['major_ver_percentage'])),
     cnxn.commit()
     cnxn.close

cnxn.close()

print newdata.to_json(orient='index')
